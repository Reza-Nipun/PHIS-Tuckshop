<?php

session_start();

class Store_Category extends CI_Controller {

    //put your code here
    public function __construct() {
        parent::__construct();
        $this->load->model('store_category_model');
        
        
        
        $admin_id = $this->session->userdata('admin_id');

        //echo '----'.$admin_id;
        //exit();
        if ($admin_id == NULL) {
            redirect('admin_login', 'refresh');
        }
        
        
    }

    public function index() {
        $data = array();
        //$data['all_catecory'] = $this->store_category_model->select_all_category();

        $data['title'] = 'Home';
        $data['main_content'] = $this->load->view('home_menu', '', true);
        $this->load->view('home', $data);
    }

    
    
    // Category Information Add, Save, Edit, Delete .............
    
    public function store_category_add_form() {
        $data = array();
        $data['title'] = 'Add Store Category';
        $data['main_content'] = $this->load->view('add_store_category', '', true);
        $this->load->view('home', $data);
    }

    public function save_store_category() {
        $data = array();
        $data['st_category_name'] = $this->input->post('st_category_name', true);
        $data['st_category_description'] = $this->input->post('st_category_description', true);

        $this->store_category_model->save_store_category_info($data);

        $sdata = array();
        $sdata['message'] = 'Category information saved successfully !';
        $this->session->set_userdata($sdata);
        redirect('store_category/store_category_add_form');
    }

    public function view_category() {
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/view_category/';
        $config['total_rows'] = $this->db->count_all('tbl_store_category');
        $config['per_page'] = '20';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data = array();
        $data['title'] = 'Category Preview';
        $data['category'] = $this->store_category_model->select_all_category($config['per_page'], $this->uri->segment(3));
        $data['main_content'] = $this->load->view('category_preview', $data, TRUE);
        $this->load->view('home', $data);
    }

    public function edit_category($st_category_id) {
        $data = array();
        $data['title'] = 'Edit Category';
        $data['category_info'] = $this->store_category_model->edit_category_by_category_id($st_category_id);
        $data['main_content'] = $this->load->view('edit_category_form', $data, true);
        $this->load->view('home', $data);
    }

    public function update_st_category_list() {
        $data = array();
        $data['st_category_id'] = $this->input->post('st_category_id', TRUE);
        $data['st_category_name'] = $this->input->post('st_category_name', TRUE);
        $data['st_category_description'] = $this->input->post('st_category_description', TRUE);
        $this->store_category_model->update_store_category($data);
        
        $sdata=array();
        $sdata['message']='Category successfully updated';
        $this->session->set_userdata($sdata);
        redirect('store_category/view_category');
    }
    
        public function delete_category($st_category_id) {
        $this->store_category_model->delete_category_info($st_category_id);
        
        $sdata=array();
        $sdata['message']='Category successfully Deleted';
        $this->session->set_userdata($sdata);
        redirect('store_category/view_category');
    }

    
    

    public function add_employer() {
        $data = array();
        $data['title'] = 'Add Employer';
        $data['main_content'] = $this->load->view('add_employer_form', '', TRUE);
        $this->load->view('home', $data);
    }

    public function add_employer_info() {
        $data = array();
        $data['employee_name'] = $this->input->post('employee_name', TRUE);
        $data['designation'] = $this->input->post('designation', TRUE);
        $data['employee_status'] = $this->input->post('employee_status', TRUE);
        $data['employer_info'] = $this->store_category_model->save_employer_info($data);

        $sdata=array();
        $sdata['message']='One employer successfully added';
        $this->session->set_userdata($sdata);
        redirect('store_category/add_employer');
    }
    
    public function view_employee(){
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/view_employee';
        $config['total_rows'] = $this->db->count_all('tbl_employee');
        $config['per_page'] = '20';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data=array();
        $data['title']='View Employee';
        $data['employee_info']=$this->store_category_model->view_all_employee($config['per_page'], $this->uri->segment(3));
        $data['main_content'] = $this->load->view('employee_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function edit_employee($employee_id){
        $data=array();
        $data['title'] = 'Edit Employee';
        $data['employee_info'] = $this->store_category_model->edit_employee_by_employee_id($employee_id);
        $data['main_content'] = $this->load->view('edit_employee_form', $data, true);
        $this->load->view('home', $data);
    }

    public function update_employee(){
        $data = array();
        $data['employee_id'] = $this->input->post('employee_id', TRUE);
        $data['employee_name'] = $this->input->post('employee_name', TRUE);
        $data['designation'] = $this->input->post('designation', TRUE);
        $data['employee_status'] = $this->input->post('employee_status', TRUE);
        $this->store_category_model->update_employee_info($data);
        
        $sdata=array();
        $sdata['message']='Employer Info successfully updated';
        $this->session->set_userdata($sdata);
        redirect('store_category/view_employee');
    }

    public function store_item_add_form() {

        $data = array();
        $data['title'] = 'Add Store Item';
        $data['all_catecory'] = $this->store_category_model->select_all_category_1();

        $data['main_content'] = $this->load->view('store_item_add_form', $data, true);
        $this->load->view('home', $data);
    }

    public function Save_store_item() {
        $data = array();
        $data['date'] = $this->input->post('date', true);
        $data['category_id'] = $this->input->post('category_id', true);

        $data['item_specification'] = $this->input->post('item_specification', true);
        $data['item_quantity'] = $this->input->post('item_quantity', true);
        $data['item_source'] = $this->input->post('item_source', true);
        $data['item_remarks'] = $this->input->post('item_remarks', true);

        $this->store_category_model->save_store_item_info($data);
        
        $sdata=array();
        $sdata['message']='Your Item Successfully Added to Store';
        $this->session->set_userdata($sdata);
       
        redirect('store_category/store_item_add_form');
    }

    public function update_store_item() {
        $data = array();
        $item_id = $this->input->post('item_id', true);
        $data['date'] = $this->input->post('date', true);
        $data['category_id'] = $this->input->post('category_id', true);

        $data['item_specification'] = $this->input->post('item_specification', true);
        $data['item_quantity'] = $this->input->post('item_quantity', true);
        $data['item_source'] = $this->input->post('item_source', true);
        $data['item_remarks'] = $this->input->post('item_remarks', true);


        //echo '<pre>';
        //print_r($data);
        //exit();

        $this->store_category_model->update_store_item_info($data, $item_id);

        redirect('store_category/item_preview');
    }

    // Pagination ...........

    public function item_preview() {
        $data = array();
        $data['title'] = 'Item Preview';

        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/item_preview/';
        $config['total_rows'] = $this->db->count_all('tbl_store_item');
        $config['per_page'] = '15';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);

        $data['item_info'] = $this->store_category_model->select_all_item($config['per_page'], $this->uri->segment(3));

        $data['main_content'] = $this->load->view('item_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function delete_item($item_id) {
        $this->store_category_model->delete_item_info($item_id);
        redirect("store_category/item_preview");
    }

    public function edit_item($item_id) {
        $data = array();
        //$data['item_info']=$this->store_category_model->edit_item_by_item_id($item_id);
        $data['item_id'] = $item_id;
        $data['all_catecory'] = $this->store_category_model->select_all_category_1();
        $data['title'] = "Edit Item";

        //echo '<pre>';
        //print_r($data);
        // exit();

        $data['main_content'] = $this->load->view('edit_item', $data, true);
        $this->load->view('home', $data);
    }

    public function store_distribute_form() {
        $data = array();
        $data['title'] = 'Distribute Item';
        $data['all_catecory'] = $this->store_category_model->select_all_category_1();
        $data['all_employee'] = $this->store_category_model->select_all_employee();
        //echo '<pre>';
        //print_r($data['all_catecory']);
        //exit();

        $data['main_content'] = $this->load->view('distribute_form', $data, true);
        $this->load->view('home', $data);
    }

    public function save_distribute_item() {
        $data = array();
        $data['date'] = $this->input->post('date', true);
        $data['receiver_id'] = $this->input->post('receiver_id', true);
        $data['designation'] = $this->input->post('designation', true);
        $data['item_id'] = $this->input->post('item_id', true);
        $data['item_specification'] = $this->input->post('item_specification', true);
        $data['item_quantity'] = $this->input->post('item_quantity', true);
        $data['remarks'] = $this->input->post('remarks', true);

        $this->store_category_model->save_distribute_item_info($data);
        
        $sdata=array();
        $sdata['message']='Distributed Item Successfully Add to Database';
        $this->session->set_userdata($sdata);
        redirect('store_category/store_distribute_form');
    }

    public function view_received_item() {
        $data = array();
        $data['title'] = 'Received Item Preview';
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/view_received_item/';
        $config['total_rows'] = $this->db->count_all('tbl_distribute');
        $config['per_page'] = '10';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);

        $data['received_item_info'] = $this->store_category_model->view_received_item($config['per_page'], $this->uri->segment(3));
        $data['main_content'] = $this->load->view('received_item_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function search_received_item_preview() {
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/search_received_item_preview/';
        //$config['total_rows'] = $this->db->count_all('tbl_distribute');
        $config['per_page'] = '6';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);

        $data = array();
        $data['title'] = 'Received Item Preview';
        $receiver_name = $this->input->post('receiver_name');
        $data['received_item_info'] = $this->store_category_model->search_by_receiver_name($receiver_name);
        $data['main_content'] = $this->load->view('received_item_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function search_by_date_received_item_preview() {
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/search_by_date_received_item_preview/';
        //$config['total_rows'] = $this->db->count_all('tbl_distribute');
        $config['per_page'] = '6';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data = array();
        $received_date = array();
        $data['title'] = 'Received Item Preview';

        $received_date1 = $this->input->post('date1');
        $received_date2 = $this->input->post('date2');
        $data['received_item_info'] = $this->store_category_model->search_receiver_by_date($received_date1, $received_date2);
        $data['main_content'] = $this->load->view('received_item_preview', $data, true);
        $this->load->view('home', $data);
    }
    
    public function search_name_with_date_received_item_preview(){
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/search_name_with_date_received_item_preview/';
        //$config['total_rows'] = $this->db->count_all('tbl_distribute');
        $config['per_page'] = '6';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data=array();
        $data['title'] = 'Received Item Preview';
        $data['name']=$this->input->post('receiver_name');
        $data['date1']=$this->input->post('date1');
        $data['date2'] = $this->input->post('date2');

        $data['received_item_info'] = $this->store_category_model->search_receiver_by_name_date($data);
        $data['main_content'] = $this->load->view('received_item_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function store_return_form() {
        $data = array();
        $data['title'] = 'Return Item';
        $data['all_catecory'] = $this->store_category_model->select_all_category_1();
        $data['all_employee'] = $this->store_category_model->select_all_employee();
        $data['main_content'] = $this->load->view('return_form', $data, true);
        $this->load->view('home', $data);
    }

    public function save_returned_item() {
        $data = array();
        $data['date'] = $this->input->post('date', true);
        $data['returner_id'] = $this->input->post('returner_id', true);
        $data['designation'] = $this->input->post('designation', true);
        $data['item_id'] = $this->input->post('item_id', true);
        $data['item_specification'] = $this->input->post('item_specification', true);
        $data['item_quantity'] = $this->input->post('item_quantity', true);
        $data['remarks'] = $this->input->post('remarks', true);

        $this->store_category_model->save_return_item_info($data);

        redirect('store_category/store_distribute_form');
    }

    public function view_returned_item() {
        $data = array();
        $data['title'] = 'Returned Item Preview';
        $data['returned_item_info'] = $this->store_category_model->view_returned_item();
        $data['main_content'] = $this->load->view('returned_item_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function employee_status() {
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/employee_status';
        $config['total_rows'] = $this->db->count_all('tbl_employee');
        $config['per_page'] = '10';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data = array();
        $data['title'] = ' Employee Status';
        $data['employee_status'] = $this->store_category_model->check_employee_status($config['per_page'], $this->uri->segment(3));

        $data['main_content'] = $this->load->view('employee_status_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function search_employee_status() {
        
         $this->load->library('pagination');

        $this->pagination->initialize();
        
        $data = array();
        $data['title'] = 'Search employee_status';
        $employee_name = $this->input->post('employer_name');
        $data['employee_status'] = $this->store_category_model->search_employee_status($employee_name);

        $data['main_content'] = $this->load->view('employee_status_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function add_defect_form() {
        $data = array();
        $data['title'] = 'Add Defect Item';
        $data['all_catecory'] = $this->store_category_model->select_all_category_1();

        $data['main_content'] = $this->load->view('add_defect_item', $data, true);
        $this->load->view('home', $data);
        
        
    }

    public function save_defect_item() {
        $data = array();
        $data['date'] = $this->input->post('date', true);
        $data['item_id'] = $this->input->post('item_id', true);

        $data['item_specification'] = $this->input->post('item_specification', true);
        $data['item_quantity'] = $this->input->post('item_quantity', true);
        $data['defect_type'] = $this->input->post('defect_type', true);
        $data['item_remarks'] = $this->input->post('item_remarks', true);

        $this->store_category_model->save_defect_item_info($data);
        
        $sdata=array();
        $sdata['message']='Defected Item Successfully Add to Database';
        $this->session->set_userdata($sdata);
        redirect('store_category/add_defect_form');
        
    }

    public function view_defect_item() {
        $data = array();
        $data['title'] = 'View Defect Item';
        $data['defect_item_info'] = $this->store_category_model->view_defect_item();

        $data['main_content'] = $this->load->view('defect_item_preview', $data, true);
        $this->load->view('home', $data);
    }

    //not need this.....  

    public function item_total_preview() {
        $data = array();
        $data['title'] = 'Total Item Preview';
        $data['total_item_info'] = $this->store_category_model->select_preview_total_item();

        //echo '<pre>';
        //print_r($data['total_item_info']);
        //exit();

        $data['main_content'] = $this->load->view('total_item_preview', $data, true);
        $this->load->view('home', $data);
    }

//not need this.....  

    public function stock_preview() {
        $data = array();
        $data['title'] = 'Total Stock Preview';
        $data['stock_item_info'] = $this->store_category_model->check_stock_item();

        //echo '<pre>';
        //print_r($data['stock_item_info']);
        //exit();

        $data['main_content'] = $this->load->view('stock_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function net_stock_preview() {
        
        $this->load->library('pagination');
        $config['base_url'] = base_url() . 'store_category/net_stock_preview';
        $config['total_rows'] = $this->db->count_all('tbl_store_category');
        $config['per_page'] = '20';
        $config['page_tag_open'] = '<p>';
        $config['page_tag_close'] = '</p>';
        $this->pagination->initialize($config);
        
        $data = array();
        $data['title'] = 'Total Stock Preview';
        $data['net_stock_item_info'] = $this->store_category_model->net_stock_item($config['per_page'], $this->uri->segment(3));

        //echo '<pre>';
        //print_r($data['net_stock_item_info']);
        //exit();

        $data['main_content'] = $this->load->view('net_stock_preview', $data, true);
        $this->load->view('home', $data);
    }

    public function search_net_stock_preview() {
        
         $this->load->library('pagination');
        //$config['base_url'] = base_url() . 'store_category/search_name_with_date_received_item_preview/';
        //$config['total_rows'] = $this->db->count_all('tbl_distribute');
        //$config['per_page'] = '6';
        //$config['page_tag_open'] = '<p>';
        //$config['page_tag_close'] = '</p>';
        $this->pagination->initialize();
        
        
        $data = array();

        $item_name = $this->input->post('item_name');
        $data['net_stock_item_info'] = $this->store_category_model->search_net_stock_by_item_name($item_name);

        $data['main_content'] = $this->load->view('net_stock_preview', $data, true);
        $this->load->view('home', $data);
    }
    
    
    
    
    
    
    
    
     // just for test use
    
    public function test_form(){
        $data=array();
        $data['main_content'] = $this->load->view('test_form', $data, true);
        $this->load->view('home', $data);
    }
    
    

    public function save_distribute_item_test() {
        $date = $this->input->post('date');
        $receiver_id = $this->input->post('receiver_id');
        $item_id = $this->input->post('item_id');
        $qty = $this->input->post('item_quantity');
        $remarks = $this->input->post('item_remarks');

        foreach ($item_id as $key => $value) {
            $data[] = array(
                'date' => $date['0'],
                'receiver_id' => $receiver_id['0'],
                'item_id' => $item_id[$key],
                'qty' => $qty[$key],
                'remarks' => $remarks['0']
            );
        }
        //echo '<pre>';
        //print_r($data);
        //exit();
        
        $this->store_category_model->save_distribute_item_info_test($data);

        $sdata = array();
        $sdata['message'] = 'Distributed Item Successfully Add to Database';
        $this->session->set_userdata($sdata);
        redirect('store_category/test_form');
    }
    
    
    
    public function test_form_1(){
        $data=array();
        $data['main_content'] = $this->load->view('test_form_1', $data, true);
        $this->load->view('home', $data);
    }
    
    
    
     public function save_distribute_item_test_1() {
         
         
        $date = $this->input->post('date');
        $receiver_id = $this->input->post('receiver_id');
        $item_id = $this->input->post('item_id');
        $qty = $this->input->post('item_quantity');
        $remarks = $this->input->post('item_remarks');

        foreach ($item_id as $key => $value) {
            $data[] = array(
                'date' => $date['0'],
                'receiver_id' => $receiver_id['0'],
                'item_id' => $item_id[$key],
                'qty' => $qty[$key],
                'remarks' => $remarks['0']
            );
        }
        echo '<pre>';
        print_r($data);
        exit();
        
        $this->store_category_model->save_distribute_item_info_test($data);

        $sdata = array();
        $sdata['message'] = 'Distributed Item Successfully Add to Database';
        $this->session->set_userdata($sdata);
        redirect('store_category/test_form');
    }
    
    

}



