<?php

class Store_Category_Model extends CI_Model {

    //put your code here

    public function save_store_category_info($data) {
        $this->db->insert('tbl_store_category', $data);
    }
    
    public function edit_category_by_category_id($st_category_id){
        $this->db->select('*');
        $this->db->from('tbl_store_category');
        $this->db->where('st_category_id',$st_category_id);
        $query_result=$this->db->get();
        $result=$query_result->row();
        return $result;
    }

    public function update_store_category($data){
        $this->db->where('st_category_id', $data['st_category_id']);
        $this->db->update('tbl_store_category',$data);
        
    }
    
    public function delete_category_info($st_category_id){
        $this->db->where('st_category_id',$st_category_id);
        $this->db->delete('tbl_store_category');
    }

    
    public function select_all_category($perpage, $offset) {
        $this->db->select('*');
        $this->db->from('tbl_store_category');
        $query_result = $this->db->get('',$perpage, $offset);
        $result = $query_result->result();
        return $result;
    }
   
    public function select_all_category_1() {
        $this->db->select('*');
        $this->db->from('tbl_store_category');
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }
    
    
    public function save_employer_info($data) {
        $this->db->insert('tbl_employee', $data);
    }

    public function select_all_employee() {
        $this->db->select('*');
        $this->db->from('tbl_employee');
        $this->db->where('employee_status',1);
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }
    public function view_all_employee($perpage, $offset) {
        $offset = (int)$offset;
        $this->db->select('*');
        $this->db->from('tbl_employee');
        $this->db->order_by("employee_name", "asc");
        $query_result = $this->db->get('',$perpage, $offset);
        $result = $query_result->result();
        return $result;
        
    }
    
    public function edit_employee_by_employee_id($employee_id){
        $this->db->select('*');
        $this->db->from('tbl_employee');
        $this->db->where('employee_id',$employee_id);
        $query_result=$this->db->get();
        $result=$query_result->row();
        return $result;
    }

    public function update_employee_info($data){
        $this->db->where('employee_id', $data['employee_id']);
        $this->db->update('tbl_employee',$data);
    }

        public function save_store_item_info($data) {
        $this->db->insert('tbl_store_item', $data);
    }


    public function update_store_item_info($data,$item_id) {
        $this->db->where('item_id', $item_id);
        $this->db->update('tbl_store_item', $data);
    }
    
    public function save_distribute_item_info($data){
        $this->db->insert('tbl_distribute', $data);
    }
    
 
    public function save_defect_item_info($data){
        $this->db->insert('tbl_defect_item', $data);
    }

    public function view_defect_item(){
        $this->db->select('sc.st_category_id, sc.st_category_name');
        $this->db->select_sum('di.item_quantity', 'total_defect_qty');
            $this->db->from('tbl_defect_item di'); 
            $this->db->join('tbl_store_category sc', 'di.item_id=sc.st_category_id', 'left');
            $this->db->group_by('di.item_id'); 
            $this->db->order_by('di.item_id');
            $query = $this->db->get(); 
            $result=$query->result();
            
            //echo '<pre>';
            //print_r($result);
            //exit();
            
            if($query->num_rows() != 0)
            {
                return ($result);
            }
            else
            {
                return false;
            }
    }

    



    public function save_store_item_info_total($data) {
        $this->db->select('*');
        $this->db->from('tbl_store_item');
        $this->db->where('category_id', $data['category_id']);
        $query_result = $this->db->get();
        $result = $query_result->row();
        return $result;
    }

    public function add_item_total_tbl($tdata) {
        $this->db->insert('tbl_store_item_total', $tdata);
    }
    
    

    public function select_all_item($per_page, $offset) {
        $offset = (int)$offset;
        //$this->db->select('*');
        //$this->db->from('tbl_store_item');
        $sql="select p.st_category_name,st.item_id,st.item_specification,st.item_quantity,st.item_source,st.item_remarks,st.date
                from tbl_store_item  as st 
                join tbl_store_category as p on st.category_id=p.st_category_id ORDER BY st.date DESC  lIMIT $per_page OFFSET $offset "; 
        $query_result = $this->db->query($sql); 
        
        $result = $query_result->result();
        return $result;
    }
    


    public function delete_item_info($item_id) {
        $this->db->where('item_id', $item_id);
        $this->db->delete('tbl_store_item');
    }

    public function edit_item_by_item_id($item_id) {
        $this->db->select('*');
        $this->db->from('tbl_store_item');
        $this->db->where('item_id', $item_id);
        $query_result = $this->db->get();
        $result = $query_result->result();
        return $result;
    }
    
    
    
    public function view_received_item($perpage,$offset){
        $offset = (int)$offset;
        $this->db->select('p.st_category_name,sl.item_id,sl.item_specification,sl.item_quantity,sl.remarks,sl.designation,sl.date,em.employee_name');
        $this->db->from('tbl_distribute sl');
        $this->db->join('tbl_store_category p', 'sl.item_id=p.st_category_id', 'left');
        $this->db->join('tbl_employee em ','sl.receiver_id=em.employee_id',  'left');
        $this->db->order_by("sl.date", "desc"); 
        $query_result = $this->db->get('',$perpage, $offset);
        
        $result = $query_result->result();
        return $result;
        
       /*$sql="select p.st_category_name,sl.item_id,sl.item_specification,sl.item_quantity,
                sl.remarks,sl.designation,sl.date,em.employee_name
                from tbl_distribute as sl 
                join tbl_store_category as p on sl.item_id=p.st_category_id 
                left outer join tbl_employee as em on sl.receiver_id=em.employee_id";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();
        return $result; 
        */
        
        
        
    }

    public function search_by_receiver_name($receiver_name){
        $sql="select p.st_category_name,sl.item_id,sl.item_specification,sl.item_quantity,
                sl.remarks,sl.designation,sl.date,em.employee_name
                from tbl_distribute as sl 
                join tbl_store_category as p on sl.item_id=p.st_category_id 
                left outer join tbl_employee as em on sl.receiver_id=em.employee_id
                where em.employee_name LIKE '%$receiver_name%' or  p.st_category_name LIKE '%$receiver_name%' ";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();
        return $result;
    }
    
        public function search_receiver_by_date($received_date1,$received_date2){
        $sql="select p.st_category_name,sl.item_id,sl.item_specification,sl.item_quantity,
                sl.remarks,sl.designation,sl.date,em.employee_name
                from tbl_distribute as sl 
                join tbl_store_category as p on sl.item_id=p.st_category_id 
                left outer join tbl_employee as em on sl.receiver_id=em.employee_id
                where sl.date BETWEEN '$received_date1' AND '$received_date2'";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();
        return $result;
    }

    public function search_receiver_by_name_date($data){
        $this->db->select('em.employee_id, em.employee_name,sl.designation,p.st_category_name,sl.item_specification,sl.item_quantity,sl.remarks,sl.date, sl.item_id');
        $this->db->from('tbl_distribute sl');
        $this->db->join('tbl_store_category p','sl.item_id=p.st_category_id', 'left');
        $this->db->join('tbl_employee em','sl.receiver_id=em.employee_id', 'left');
        $this->db->like('em.employee_name', $data['name']);
        $this->db->where('sl.date >=', $data['date1'] );
        $this->db->where('sl.date <=', $data['date2'] );
        $this->db->group_by('sl.item_id'); 
        $this->db->order_by('sl.date');
        $query = $this->db->get(); 
        $result=$query->result();
        
            //echo '<pre>';
            //print_r($result);
            //exit();
            
            if($query->num_rows() != 0)
            {
                return ($result);
            }
            else
            {
                return false;
            }
    }

    



    public function save_return_item_info($data){
        $this->db->insert('tbl_return', $data);
    }
    
    public function view_returned_item(){
        $sql="select p.st_category_name,rt.item_id,rt.item_specification,rt.item_quantity,
                rt.remarks,rt.designation,rt.date,em.employee_name
                from tbl_return as rt 
                join tbl_store_category as p on rt.item_id=p.st_category_id 
                left outer join tbl_employee as em on rt.returner_id=em.employee_id";
        $query_result = $this->db->query($sql);
        $result = $query_result->result();
        return $result; 
    }

    
    
    public function check_employee_status($per_page, $offset){
        $offset = (int)$offset;
        
       $sql="select em.employee_id,em.employee_name,em.designation,sl.item_id,p.st_category_name,
                IFNULL(sl.sl_total_qty,0) as sl_total_qty,IFNULL(rt.rt_total_qty,0) as rt_total_qty,
                IFNULL(sl.sl_total_qty,0)-IFNULL(rt.rt_total_qty,0) as em_crnt_sts
                from tbl_employee as em
                left join
                (
                select item_id,receiver_id, sum(item_quantity) as sl_total_qty from tbl_distribute group by receiver_id, item_id
                ) as sl on sl.receiver_id=em.employee_id left outer join
                (
                select returner_id, sum(item_quantity) as rt_total_qty from tbl_return Group by returner_id,item_id
                ) as rt on rt.returner_id=em.employee_id 
                 left outer join
                (
                select st_category_name,st_category_id  from tbl_store_category
                )
                as p on sl.item_id=p.st_category_id  ORDER BY em.employee_name ASC  lIMIT $per_page OFFSET $offset";
        $query_result=$this->db->query($sql);
        $result=$query_result->result();
        return $result;
        }
        
    public function search_employee_status($employee_name){
        $sql="select em.employee_id,em.employee_name,em.designation,sl.item_id,p.st_category_name,
                IFNULL(sl.sl_total_qty,0) as sl_total_qty,IFNULL(rt.rt_total_qty,0) as rt_total_qty,
                IFNULL(sl.sl_total_qty,0)-IFNULL(rt.rt_total_qty,0) as em_crnt_sts
                from tbl_employee as em
                left join
                (
                select item_id,receiver_id, sum(item_quantity) as sl_total_qty from tbl_distribute group by receiver_id, item_id
                ) as sl on sl.receiver_id=em.employee_id left outer join
                (
                select returner_id, sum(item_quantity) as rt_total_qty from tbl_return Group by returner_id,item_id
                ) as rt on rt.returner_id=em.employee_id 
                 left outer join
                (
                select st_category_name,st_category_id  from tbl_store_category
                )
                as p on sl.item_id=p.st_category_id where em.employee_name LIKE '%$employee_name%' or st_category_name LIKE '%$employee_name%' ";
        $query_result=$this->db->query($sql);
        $result=$query_result->result();
        return $result;
    }

        
//not need this.....  
    
        public function select_preview_total_item(){
     $sql="SELECT item_name, sum(item_quantity)As total_item_quantity from tbl_store_item Group By category_id";
        $query_result=$this->db->query($sql);
        $result=$query_result->result();
        return $result;
    }
    
    //not need this.....  
    
    public function check_stock_item(){
       $sql="SELECT p.st_category_name, 
           IFNULL(st.store_qty, 0) As store_qty,
           IFNULL(sl.distribute_qty, 0) As distribute_qty,
           IFNULL(st.store_qty, 0)- IFNULL(sl.distribute_qty, 0) As stock_qty 
           from tbl_store_category as p 
           left join 
           ( 
           select category_id, sum(item_quantity) As store_qty from tbl_store_item GROUP BY category_id 
           ) as st
           on p.st_category_id=st.category_id 
           left outer join 
           ( 
           select item_id, sum(item_quantity) As distribute_qty from tbl_distribute GROUP BY item_id 
           ) as sl 
           on p.st_category_id=sl.item_id ";
          

       
        $query_result=$this->db->query($sql);
        $result=$query_result->result();
        return $result; 
    }

    
    
    
  public function net_stock_item($per_page, $offset) {
        $offset = (int) $offset;
        $sql = "select p.st_category_id, p.st_category_name,
               IFNULL(st.t_st_qty, 0) as t_st_qty,
               IFNULL(sl.t_sl_qty, 0) as t_sl_qty,
               IFNULL(df.t_df_qty, 0) as t_df_qty,
               IFNULL(rt.t_rt_qty, 0) as t_rt_qty,
               IFNULL(sl.t_sl_qty, 0)-IFNULL(rt.t_rt_qty, 0) as t_distribute,
               IFNULL(st.t_st_qty, 0)-IFNULL(sl.t_sl_qty, 0)+IFNULL(rt.t_rt_qty, 0)-IFNULL(df.t_df_qty, 0) as net_stock
               from tbl_store_category as p
                left join 
               (
               select category_id,sum(item_quantity) as t_st_qty from tbl_store_item Group by category_id 
               ) as st on p.st_category_id=st.category_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_sl_qty from tbl_distribute Group by item_id
               ) as sl on p.st_category_id=sl.item_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_rt_qty from tbl_return Group by item_id
               ) as rt on p.st_category_id=rt.item_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_df_qty from tbl_defect_item Group by item_id
               ) as df on p.st_category_id=df.item_id ORDER BY p.st_category_name ASC  lIMIT $per_page OFFSET $offset";

        $query_result = $this->db->query($sql);
        $result = $query_result->result();
        return $result;
    }

    public function search_net_stock_by_item_name($item_name){
        $sql = "select p.st_category_id, p.st_category_name,
               IFNULL(st.t_st_qty, 0) as t_st_qty,
               IFNULL(sl.t_sl_qty, 0) as t_sl_qty,
               IFNULL(df.t_df_qty, 0) as t_df_qty,
               IFNULL(rt.t_rt_qty, 0) as t_rt_qty,
               IFNULL(sl.t_sl_qty, 0)-IFNULL(rt.t_rt_qty, 0) as t_distribute,
               IFNULL(st.t_st_qty, 0)-IFNULL(sl.t_sl_qty, 0)+IFNULL(rt.t_rt_qty, 0)-IFNULL(df.t_df_qty, 0) as net_stock
               from tbl_store_category as p
                left join 
               (
               select category_id,sum(item_quantity) as t_st_qty from tbl_store_item Group by category_id 
               ) as st on p.st_category_id=st.category_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_sl_qty from tbl_distribute Group by item_id
               ) as sl on p.st_category_id=sl.item_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_rt_qty from tbl_return Group by item_id
               ) as rt on p.st_category_id=rt.item_id
               left outer join
               (
               select item_id, sum(item_quantity) as t_df_qty from tbl_defect_item Group by item_id
               ) as df on p.st_category_id=df.item_id where p.st_category_name LIKE '%$item_name%' ";
          

       
        $query_result=$this->db->query($sql);
        $result=$query_result->result();
        return $result; 
    }
    
    
    
    
    
    
    public function save_distribute_item_info_test($data) {
        $this->db->insert_batch('tbl_test_disribute', $data);
    }

}


