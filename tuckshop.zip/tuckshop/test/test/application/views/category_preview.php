
<h3 style="margin-left: 200px;">All Category </h3>

<h4 style="margin-left: 200px">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>






<table border="2" style="margin-left: 100px;">
    
    
    <tr> 
        <td>Category Name</td>
        <td>Category Details</td>
        
        
        <?php if($this->session->userdata('role') == 1): ?>
        <td>Edit</td>
        <td>Delete</td>
        <?php endif; ?>
    </tr>
    
     <?php
            foreach ($category as $values){
     ?>
    
    <tr>
        
        <td><?php echo $values->st_category_name?></td>
        <td><?php echo $values->st_category_description?></td>
        
        <?php if($this->session->userdata('role') == 1): ?>
        <td>
            <a href="<?php echo base_url();?>store_category/edit_category/<?php echo $values->st_category_id;?>">Edit</a>
        </td>
        <td>
            <a href="<?php echo base_url();?>store_category/delete_category/<?php echo $values->st_category_id;?> "  onclick="return CheckDelete();" >Delete</a>
        </td>
        <?php endif;?>
        
    </tr>
    
    
    
     <?php }?>
    
</table>

<div class="pagination">
        <?php echo $this->pagination->create_links(); ?>
 </div> 
