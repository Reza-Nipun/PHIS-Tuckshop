

<h3 style="text-align: center;">Add Defect Item</h3>
<hr>
<h4 style="text-align: center;">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>


<form action="<?php echo base_url();?>store_category/save_defect_item" method="post">
    
    <table cellspacing="10px" align="center">
        <tr>
            <td>Date</td>
            <td>
                <input type="date" name="date" size="37" required="1">
            </td>
        </tr>
        
        <tr>
            <td>Item Name</td>
            <td>
                <select name="item_id" required="1">
                    <option value="" disabled selected>Select your item name</option>
                    
                        <?php
                            foreach ($all_catecory as $values){
                         ?>
                            
                    <option value="<?php echo $values->st_category_id ?>"><?php echo $values->st_category_name ?></option>   
                        
                        <?php
                            }
                        ?>
                    
                </select>
            </td>
        </tr>

        <tr>
            <td>Item Specification</td>
            <td>
                <textarea cols="33" id="description" rows="3" name="item_specification" required="1"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>Item Quantity</td>
            <td>
                <input type="number" name="item_quantity" size="37" required="1">
            </td>
        </tr>
        
        <tr>
            <td>Defect Type</td>
            <td>
                <input type="text" name="defect_type" size="37" required="1">
            </td>
        </tr>
        
        <tr>
            <td>Item Remarks<br>(Defected Item User)</td>
            <td>
                <textarea cols="33" id="item_remarks" rows="3" name="item_remarks" required="1"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" name="btn" value="Save">
            </td>
        </tr>
    </table>
</form> 

