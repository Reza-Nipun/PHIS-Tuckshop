

<script type="text/javascript" src="http://jqueryjs.googlecode.com/files/jquery-1.3.2.min.js"></script>

<style type="text/css">
    div{
        padding:0px;
    }
    
    label{width: 100px;}
    
</style>




<h1>jQuery add / remove </h1>

<script type="text/javascript">

$(document).ready(function(){

    var counter = 2;

    $("#addButton").click(function () {

    if(counter>10){
            alert("Only 10 textboxes allow");
            return false;
    }   

    var newTextBoxDiv = $(document.createElement('tr'))
         .attr("id", 'TextBoxDiv' + counter);

         
    newTextBoxDiv.after().html('<label>Item ID #'+ counter + ' : </label>' +
          '<input type="text" name="item_id[]" id="textbox' + counter + '" value="" >' + '<label>Item Quantity #'+ counter + ' : </label>' +
          '<input type="number" name="item_quantity[]" id="textbox' + counter + '" value="" >');

    newTextBoxDiv.appendTo("#frm_TextBoxesGroup");


    counter++;
     });

     $("#removeButton").click(function () {
    if(counter==1){
          alert("No more textbox to remove");
          return false;
       }   

    counter--;

        $("#TextBoxDiv" + counter).remove();

     });

     $("#getButtonValue").click(function () {

    var msg = '';
    for(i=1; i<counter; i++){
      msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
    }
          alert(msg);
     });
  });
</script>




<div id='TextBoxesGroup'>
    <form action="<?php echo base_url(); ?>store_category/save_distribute_item_test_1" method="post" id="frm_TextBoxesGroup">
        <table>
            <tr><td><label>Date</label><input type="date" name="date[]"></td></tr>
            <tr><td><label>Receiver ID</label><input type="text" name="receiver_id[]"></td></tr>
            <tr><td>
                    <label>Item ID #1 : </label><input type='textbox' id='textbox1' name="item_id[]" >
                    <label>Item Quantity #1 : </label><input type='number' id='textbox1' name="item_quantity[]" >

                </td>
            </tr>

            <tr>
                <td>
                    <input type='button' value='Add More' id='addButton'>
                    <input type='button' value='Remove One' id='removeButton'>
                    <input type='button' value='Get TextBox Value' id='getButtonValue'>
                </td>
            </tr>
            <tr><td><label>Remarks</label><textarea cols="33" id="remarks" rows="3" name="item_remarks[]"></textarea></td></tr>
            <tr><td><input type="submit" value="Save" name="btn"></td></tr>
        </table>
    </form>

</div>   


    
