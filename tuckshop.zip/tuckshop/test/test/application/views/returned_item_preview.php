
<div ><h5>
        <form action="<?php echo base_url(); ?>store_category/search_returned_item_preview" method="post">
            <input type="search" list="returner_name" placeholder="Enter returner Name" name="returner_name">
            <input type="submit" name="btn" value="Search">
        </form>

        <datalist id="employee_name">
            <?php
            foreach ($returned_item_info as $values) {
                ?>  
                <option value="<?php echo $values->employee_name; ?>">
            <?php } ?>
        </datalist>
    </h5>
</div>


    
    <table border="1" width="500" align="center">
        <tr>
            <th>Returner Name</th>
            <th>Designation</th>
            <th>Item Name</th>
            <th>Specification</th>
            <th>Quantity</th>
            <th>Remarks</th>
            <th>Date</th>

        </tr>
        
        <?php
            foreach ($returned_item_info as $values){
        ?>
        <tr>
            <td><?php echo $values->employee_name?></td>
            <td><?php echo $values->designation?></td>
            <td><?php echo $values->st_category_name?></td>
            <td><?php echo $values->item_specification?></td>
            <td><?php echo $values->item_quantity?></td>
            <td><?php echo $values->remarks?></td>
            <td><?php echo $values->date?></td>

        </tr>
        
            <?php } ?>
        
    </table>
    
    
   
 