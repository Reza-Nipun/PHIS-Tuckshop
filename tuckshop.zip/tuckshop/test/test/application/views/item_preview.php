

<h3 style="text-align: center;">All Store Item </h3>
<hr>


<div style="margin-left: 50px;">

    <table border="1" width="700" align="center">
        <tr>
            <td>Name</td>
            <td>Descpiption</td>
            <td>Quantity</td>
            <td>Source</td>
            <td>Remarks</td>
            <td>Date</td>

            <?php if ($this->session->userdata('role') == 1): ?>
                <td>Edit</td>
                <td>Delete</td>
            <?php endif; ?>
        </tr>

        <?php
        foreach ($item_info as $values) {
            ?>
            <tr>
                <td><?php echo $values->st_category_name ?></td>
                <td><?php echo $values->item_specification ?></td>
                <td><?php echo $values->item_quantity ?></td>
                <td><?php echo $values->item_source ?></td>
                <td><?php echo $values->item_remarks ?></td>
                <td><?php echo $values->date ?></td>


                <?php if ($this->session->userdata('role') == 1): ?>
                    <td>
                        <a href="<?php echo base_url(); ?>store_category/edit_item/<?php echo $values->item_id; ?>">Edit</a>
                    </td>
                    <td>
                        <a href="<?php echo base_url(); ?>store_category/delete_item/<?php echo $values->item_id; ?>" onclick="return CheckDelete();">Delete</a>
                    </td>
                <?php endif; ?>
            </tr>

        <?php } ?>

    </table>

    <div class="pagination">
        <?php echo $this->pagination->create_links(); ?>
    </div> 



</div>