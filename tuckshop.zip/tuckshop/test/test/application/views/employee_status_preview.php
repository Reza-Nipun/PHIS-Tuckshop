
<h3 style="text-align: center;">Employee Status</h3>
<hr>

<div style="text-align: center;"><h5>
        <form action="<?php echo base_url(); ?>store_category/search_employee_status" method="post">
            <input type="search" list="employer_name" placeholder="Enter Employer Name or Item Name" name="employer_name" size="30">
            <input type="submit" name="btn" value="Search">
        </form>

        <datalist id="employee_name">
            <?php
            foreach ($employee_status as $values) {
                ?>  
                <option value="<?php echo $values->employee_name; ?>">
            <?php } ?>
        </datalist>
    </h5>
</div>


    
    <table border="1" width="500" align="center">
        <tr>
            <th>Employer Name</th>
            <th>Designation</th>
            <th>Item Name</th>
            <th>Received Quantity</th>
            <th>Returned Quantity</th>
            <th>Current Status</th>

        </tr>
        
        <?php
            foreach ($employee_status as $values){
        ?>
        <tr>
            <td><?php echo $values->employee_name?></td>
            <td><?php echo $values->designation?></td>
            <td><?php echo $values->st_category_name?></td>
            <td><?php echo $values->sl_total_qty?></td>
            <td><?php echo $values->rt_total_qty?></td>
            <td><?php echo $values->em_crnt_sts?></td>

        </tr>
        
            <?php } ?>
        
    </table>
    
    
   <div class="pagination">
        <?php echo $this->pagination->create_links(); ?>
    </div> 

 