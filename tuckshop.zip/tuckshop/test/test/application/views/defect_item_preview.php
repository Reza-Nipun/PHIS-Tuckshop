
<h3 style="text-align: center;">All Defect Item </h3>
<hr>
<table align="center" style="" border="1">
    <tr>
        <td>Item Name</td>
        <td>Total Defect Item</td>
    </tr>
    <?php
        foreach ($defect_item_info as $values){
    ?>
    
    <tr>
        <td><?php echo $values->st_category_name ?></td>
    
        <td><?php echo $values->total_defect_qty ?></td>
    </tr>
    
        <?php } ?>
    
</table>