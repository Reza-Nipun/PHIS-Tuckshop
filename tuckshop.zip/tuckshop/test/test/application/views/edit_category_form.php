






<form action="<?php echo base_url();?>store_category/update_st_category_list" method="post">

<table>
    
    <tr><td><input type="hidden" name="st_category_id" value="<?php echo $category_info->st_category_id ?>"</td></tr>
    
    <tr>
        <td>Category Name</td>
        <td><input type="text" name="st_category_name" placeholder="" required="1" value="<?php echo $category_info->st_category_name ?>"</td><span class="required">*</span>
    </tr>
    <tr>
        <td>Category Description</td>
        <td><input type="text" name="st_category_description" placeholder="" required="1" value="<?php echo $category_info->st_category_description?>"</td><span class="required">*</span>
    </tr>
    <tr>
        <td>
            <input type="submit" name="btn" value="Update">
        </td>
    </tr>
</table>
    
    
</form>