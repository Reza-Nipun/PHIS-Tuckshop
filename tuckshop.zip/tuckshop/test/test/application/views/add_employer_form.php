
<h3 style="margin-left: 200px;">Add Employee</h3>

<h4 style="margin-left: 200px">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>


<form action="<?php echo base_url();?>store_category/add_employer_info" method="post">
    <table style="margin-left: 100px;">
        <tr>
            <td>Name</td><td><input type="text" required="1" name="employee_name" placeholder="Write Employer Name"></td>
        </tr>
        <tr>
            <td>Designation</td><td><input type="text" name="designation" required="1" placeholder="Write Designation"></td>
        </tr>
        <tr>
            <td>Employer Status</td>
            <td>
                <input type="radio" name="employee_status" value="1" checked="true">Active
                <input type="radio" name="employee_status" value="0">Inactive
            </td>
        </tr>
        <tr>
            <td><input type="submit" name="btn" value="Save"></td>
        </tr>
    </table>
</form>