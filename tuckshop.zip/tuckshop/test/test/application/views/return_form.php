








<form action="<?php echo base_url();?>store_category/save_returned_item" method="post">
    
    <table cellspacing="10px" align="center">
        <tr>
            <td>Date</td>
            <td>
                <input type="date" name="date" size="37">
            </td>
        </tr>
        
        <tr>
            <td>Returner Name</td>
            <td>
                <select name="returner_id">
                    <option>Select Returner name</option>
                    
                        <?php
                            foreach ($all_employee as $values){
                         ?>
                            
                    <option value="<?php echo $values->employee_id ?>"><?php echo $values->employee_name ?></option>   
                        
                        <?php
                            }
                        ?>
                    
                </select>
            </td>
        </tr>
        
        <tr>
            <td>Designation</td>
            <td>
                <select name="designation">
                    <option>Select Designation</option>
                    
                        <?php
                            foreach ($all_employee as $values){
                         ?>
                            
                    <option value="<?php echo $values->designation ?>"><?php echo $values->designation?></option>   
                        
                        <?php
                            }
                        ?>
                    
                </select>
            </td>
        </tr>
        
        
        
        <tr>
            <td>Item Name</td>
            <td>
                <select name="item_id">
                    <option>Select your item name</option>
                    
                        <?php
                            foreach ($all_catecory as $values){
                         ?>
                            
                    <option value="<?php echo $values->st_category_id ?>"><?php echo $values->st_category_name ?></option>   
                        
                        <?php
                            }
                        ?>
                    
                </select>
            </td>
        </tr>

        <tr>
            <td>Item Specification</td>
            <td>
                <textarea cols="33" id="description" rows="3" name="item_specification"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>Item Quantity</td>
            <td>
                <input type="number" name="item_quantity" size="37">
            </td>
        </tr>
        

        
        <tr>
            <td>Item Remarks</td>
            <td>
                <textarea cols="33" id="remarks" rows="3" name="item_remarks"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" name="btn" value="Save">
            </td>
        </tr>
    </table>
</form> 

