
<html>
<head>    
      
      
</head>


<body>






<h3 style="text-align: center;">Distribute Item</h3>
<hr>
<h4 style="text-align: center;">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>






<form action="<?php echo base_url(); ?>store_category/save_distribute_item_test" method="post">

    <table cellspacing="10px" align="center">
        <tr>
            <td>Date</td>
            <td>
                <input type="date" id="date" name="date[]" size="37" required="1">
            </td>
        </tr>
        
        
        <tr>
            <td>Receiver ID</td>
            <td>
                <input type="text" id="" name="receiver_id[]" size="37" required="1">
            </td>
        </tr>
    </table>
    <hr>

    <table align="center">

        <tr>
            <td>Item ID:<input type="text" id="" name="item_id[]" size="25" required="1"></td>
            <td>Item Quantity:<input type="number" name="item_quantity[]" size="37" required="1"></td>
        </tr>
        <tr>
            <td>Item ID:<input type="text" id="" name="item_id[]" size="25" required="1"></td>
            <td>Item Quantity:<input type="number" name="item_quantity[]" size="37" required="1"></td>
        </tr>
        
    </table>
    
       
    <p align="center"><button >add More</button></p>

        <table align="center">
        <tr>
            <td>Item Remarks</td>
            <td>
                <textarea cols="33" id="remarks" rows="3" name="item_remarks[]"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" name="btn" value="Save">
            </td>
        </tr>
    </table>
    

</form> 



</body>
</html>