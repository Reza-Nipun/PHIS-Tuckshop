



<h3 style="text-align: center;">Net Stock Preview</h3>
<hr>


<div style="text-align: center;" ><h5>
        <form action="<?php echo base_url(); ?>store_category/search_net_stock_preview" method="post">
            <input type="search" list="item_name" placeholder="Enter item Name" name="item_name">
            <input type="submit" name="btn" value="Search">
        </form>

        <datalist id="st_category_name">
            <?php
            foreach ($net_stock_item_info as $values) {
                ?>  
                <option value="<?php echo $values->st_category_name; ?>">
                <?php } ?>
        </datalist>
    </h5>
</div>






<table border="1" width="500" align="center">
    <tr>
        <th>Name</th>

        <th>Total Store</th>
        <th>Total Distribute</th>
        <th>Total Defect</th>
        <th>Stock</th>

    </tr>

    <?php
    foreach ($net_stock_item_info as $values) {
        ?>
        <tr>
            <td><?php echo $values->st_category_name ?></td>

            <td><?php echo $values->t_st_qty ?></td>
            <td><?php echo $values->t_distribute ?></td>
            <td><?php echo $values->t_df_qty ?></td>
            <td><?php echo $values->net_stock ?></td>

        </tr>

    <?php } ?>

</table>

<div class="pagination">
    <?php echo $this->pagination->create_links(); ?>
</div> 

