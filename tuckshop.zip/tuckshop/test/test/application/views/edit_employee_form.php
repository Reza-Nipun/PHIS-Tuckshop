

<h4 style="margin-left: 100px"> Upadate Employer Information</h4>


<form action="<?php echo base_url() ?>store_category/update_employee" method="post">
    <table border="1" style="margin-left: 100px;">
        
        <tr><td><input type="hidden" name="employee_id" value="<?php echo $employee_info->employee_id ?>"</td></tr>
        <tr>
        <td>Employer Name</td>
        <td><input type="text" required="1" name="employee_name" value="<?php echo $employee_info->employee_name ?>"></td>
        </tr>
        <tr>
        <td>Designation</td>
        <td><input type="text" required="1" name="designation" value="<?php echo $employee_info->designation ?>"></td>
        </tr>
        <tr>
            <td>Employer Status</td>
            <td>
                <input type="radio" name="employee_status" value="1" checked="true">Active
                <input type="radio" name="employee_status" value="0">Inactive
            </td>
        </tr>
        <tr>
            <td><input type="submit" name="btn" value="Update"></td>
        </tr>
    </table>

</form>