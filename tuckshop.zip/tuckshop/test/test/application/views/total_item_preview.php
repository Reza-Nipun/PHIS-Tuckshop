

 
<p></p><p></p><p></p><p></p>

    
    <table border="1" width="500" align="center">
        <tr>
            <th>Name</th>
            
            <th>Quantity</th>

        </tr>
        
        <?php
            foreach ($total_item_info as $values){
        ?>
        <tr>
            <td><?php echo $values->item_name?></td>
            
            <td><?php echo $values->total_item_quantity?></td>

        </tr>
        
            <?php } ?>
        
    </table>
    
    
   
 