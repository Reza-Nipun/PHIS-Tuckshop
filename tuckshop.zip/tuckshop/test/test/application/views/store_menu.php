              

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/store_category_add_form.jsp">Add Category</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/store_item_add_form.jsp">Add Item</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/item_preview.jsp">Item Preview</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/store_distribute_form.jsp">Received Item</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/view_received_item.jsp">View Received Item</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/store_return_form.jsp">Return Item</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/view_returned_item.jsp">View Returned Item</a></div>

<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/add_defect_form.jsp">Defect Item</a></div>


<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/employee_status.jsp">Employee Status</a></div>



<div class="home_menu"><a href="<?php echo base_url(); ?>store_category/net_stock_preview.jsp">Net Stock Item</a></div>