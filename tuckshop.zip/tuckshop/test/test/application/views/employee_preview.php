
<h4 style="margin-left: 200px">All Employee</h4>
<hr/>



<h4 style="margin-left: 200px">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>

<table style="margin-left: 100px; " border="1">
    <tr>
        <td>Employer Name</td>
        <td>Designation</td>
        <td>Edit</td>
        
    </tr>
    
    <?php foreach ($employee_info as $values){ ?>
    <tr>
        <td><?php echo $values->employee_name?></td>
        <td><?php echo $values->designation?></td>
        
        <td>
            <a href="<?php echo base_url();?>store_category/edit_employee/<?php echo $values->employee_id;?>">Edit</a>
        </td>
        
    </tr>
    
    <?php } ?>
    
</table>


<div class="pagination">
        <?php echo $this->pagination->create_links(); ?>
    </div> 
