




<p></p><p></p><p></p><p></p>

    
    <table border="1" width="500" align="center">
        <tr>
            <th>Name</th>
            
            <th>Total Store</th>
            <th>Total Distribute</th>
            <th>Stock</th>
            
        </tr>
        
        <?php
            foreach ($stock_item_info as $values){
        ?>
        <tr>
            <td><?php echo $values->st_category_name?></td>
            
            <td><?php echo $values->store_qty?></td>
            <td><?php echo $values->distribute_qty?></td>
            <td><?php echo $values->stock_qty?></td>

        </tr>
        
            <?php } ?>
        
    </table>
    
    
   