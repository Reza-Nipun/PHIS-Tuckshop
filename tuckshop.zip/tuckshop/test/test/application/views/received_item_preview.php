
<html>

    <head>

        <script>



            function show() {
                var option = document.getElementById("category").value;


                if (option == "search_by_name")
                {
                    document.getElementById("search_by_name").style.display = "block";
                    document.getElementById("search_by_date").style.display = "none";
                    document.getElementById("name_date").style.display = "none";
                }
                if (option == "search_by_date")
                {
                    document.getElementById("search_by_name").style.display = "none";
                    document.getElementById("search_by_date").style.display = "block";
                    document.getElementById("name_date").style.display = "none";
                }
                if (option == "name_date")
                {
                    document.getElementById("name_date").style.display = "block";
                    document.getElementById("search_by_name").style.display = "none";
                    document.getElementById("search_by_date").style.display = "none";
                }
            }
        </script>



    </head>

    <body onload="show()">



        <div style="">
            <table align="center">
                <tr >
                    <td><label>Search by:</label></td>
                    <td><select id="category" onchange="show()">    <!--onchange show methos is call-->

                            <option value="search_by_name"selected="selected" >Search by Name or Item Name</option>
                            <option value="search_by_date">Search by Date</option>
                            <option value="name_date">Name with Date</option>
                        </select>
                    </td>
                </tr>
            </table>

            <h5 align="center">
                <div id="search_by_name">
                    <form action="<?php echo base_url(); ?>store_category/search_received_item_preview" method="post">
                        <input type="search" list="receiver_name" placeholder="Enter receiver Name or Item Name" name="receiver_name" size="30">
                        <input type="submit" name="btn" value="Search">
                    </form>
                </div>

                <div id="search_by_date">
                    <form action="<?php echo base_url(); ?>store_category/search_by_date_received_item_preview" method="post">
                        <label>FROM</label><input type="date" id="date1" name="date1"  >
                        <label>TO</label><input type="date" id="date2" name="date2"  >
                        <input type="submit" name="btn" value="Search">
                    </form>
                </div>

                <div id="name_date">
                    <form action="<?php echo base_url(); ?>store_category/search_name_with_date_received_item_preview" method="post">
                        <label>Name</label><input type="search" list="receiver_name" placeholder="Enter receiver Name" name="receiver_name"><br>
                        <label>FROM</label><input type="date" id="date1" name="date1"  >
                        <label>TO</label><input type="date" id="date2" name="date2"  >
                        <input type="submit" name="btn" value="Search">
                    </form>
                </div>

                <datalist id="employee_name">
                    <?php
                    foreach ($received_item_info as $values) {
                        ?>  
                        <option value="<?php echo $values->employee_name; ?>">
                        <?php } ?>
                </datalist>
            </h5>
        </div>



        <table border="1" width="500" align="center">
            <tr>
                <th>Receiver Name</th>
                <th>Designation</th>
                <th>Item Name</th>
                <th>Specification</th>
                <th>Quantity</th>
                <th>Remarks</th>
                <th>Date</th>

            </tr>

            <?php
            foreach ($received_item_info as $values) {
                ?>
                <tr>
                    <td><?php echo $values->employee_name ?></td>
                    <td><?php echo $values->designation ?></td>
                    <td><?php echo $values->st_category_name ?></td>
                    <td><?php echo $values->item_specification ?></td>
                    <td><?php echo $values->item_quantity ?></td>
                    <td><?php echo $values->remarks ?></td>
                    <td><?php echo $values->date ?></td>

                </tr>

            <?php } ?>

        </table>


        <div class="pagination">
            <?php echo $this->pagination->create_links(); ?>
        </div> 

    </body>   

</html>