
<!DOCTYPE html>
<html>





<form action="<?php echo base_url();?>store_category/update_store_item" method="post">
    
    <table cellspacing="10px" align="center">
        <tr>
            
            
            
            
            <td>Date</td>
            <td>
                <input type="hidden" name="item_id" size="37" value="<?php echo $item_id; ?>">

                <input type='date' id='date' name='date' required="required">
                
            </td>
        </tr>
        
        <tr>
            <td>Item Name</td>
            <td>
                <select name="category_id">
                    <option>Select your item name</option>
                    
                        <?php
                            foreach ($all_catecory as $values){
                         ?>
                            
                    <option value="<?php echo $values->st_category_id ?>"><?php echo $values->st_category_name ?></option>   
                        
                        <?php
                            }
                        ?>
                    
                </select>
            </td>
        </tr>

        <tr>
            <td>Item Specification</td>
            <td>
                <textarea cols="33" id="description" rows="3" name="item_specification"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>Item Quantity</td>
            <td>
                <input type="number" name="item_quantity" size="37" required="required">
            </td>
        </tr>
        
        <tr>
            <td>Item Source</td>
            <td>
                <input type="text" name="item_source" size="37">
            </td>
        </tr>
        
        <tr>
            <td>Item Remarks</td>
            <td>
                <textarea cols="33" id="item_remarks" rows="3" name="item_remarks"></textarea>
            </td>
        </tr>
        
        <tr>
            <td>&nbsp;</td>
            <td>
                <input type="submit" name="btn" value="Update">
            </td>
        </tr>
    </table>
</form> 





</html>






