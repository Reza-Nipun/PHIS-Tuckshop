
<?php
echo '<h4 style="margin-left: 200px"> Welcome'.' '.'Mr.'.' '.$this->session->userdata('admin_name').'</h4>';

?>


              
<div class="home_menu"><a href="<?php echo base_url(); ?>welcome/store_menu.jsp">Store</a></div>
                    <div class="home_menu">Academic</div>
                    <div class="home_menu">Human Resources</div>
                    <div class="home_menu">House Master</div>
                    <div class="home_menu">Corporate</div>
               
                