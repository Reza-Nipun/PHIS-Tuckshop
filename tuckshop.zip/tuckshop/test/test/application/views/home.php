
<html>
    <head>
        <title><?php echo $title; ?></title>


        <link rel="stylesheet" href="<?php echo base_url(); ?>css/style.css">
        
        <link type="text/javascript" href="<?php echo base_url(); ?>js/jquery-1.8.1.min.js">
       
        

        <script type="text/javascript">
            function CheckDelete()
            {
                chk = confirm("Are you want to delete this item ?");
                if (chk)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        </script>


    </head>

    <body>


        <div id="wrapper">
            <div class="header_top">
                <div class="admin">
                    <?php
                    $admin = $this->session->userdata('admin_name');
                    if (isset($admin)) {
                        echo $admin;
                    }
                    ?>
                </div>
                <div class="logout">
                    <a href="<?php echo base_url(); ?>admin_logout/logout">Logout</a>
                </div>
            </div>
            <div id="header">

                <img src="<?php echo base_url();?>images/phsa_store.jpg">
            </div>

            <div class="clr"></div>

            <div id="container">

                <div class="content_left">
                    <?php if($this->session->userdata('role') == 1||$this->session->userdata('role') == 2): ?>
                    <table border="1">
                        <tr>
                            <td><a href="<?php echo base_url(); ?>store_category.jsp">Home</a> </td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>welcome/store_menu.jsp">Store Menu</a></td>
                        </tr>
                        <?php if($this->session->userdata('role') == 1): ?>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/store_category_add_form.jsp">Add Category</a></td>
                        </tr>
                        <?php endif; ?>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_category.jsp">View Category</a></td>
                        </tr>
                        <?php if($this->session->userdata('role') == 1): ?>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/add_employer.jsp">Add Employer</a></td>
                        </tr>
                        <?php endif;?>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_employee.jsp">View Employee </a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/store_item_add_form.jsp">Add Store Item</a></td>
                        </tr>
                        
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/item_preview.jsp">Preview Store Item</a></td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo base_url(); ?>store_category/store_distribute_form.jsp">Distribute Item</a> </td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_received_item.jsp">View Distributed Item</a></td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo base_url(); ?>store_category/store_return_form.jsp">Add Return Item</a> </td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_returned_item.jsp">View Returned Item</a></td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo base_url(); ?>store_category/add_defect_form.jsp">Add Defect Item</a> </td>
                        </tr>
                        <tr>
                            <td><a href="<?php echo base_url(); ?>store_category/view_defect_item.jsp">View Defect Item</a> </td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/employee_status.jsp">Employee Status</a></td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/net_stock_preview.jsp">Net Stock Item</a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/test_form.jsp">Test</a></td>
                        </tr>
                         <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/test_form_1.jsp">Test_1</a></td>
                        </tr>
                        
                        
                    </table>
                    <?php endif; ?>
                    
                    
                     <?php if($this->session->userdata('role') == 3): ?>
                    <table border="1">
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_category.jsp">View Category</a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_employee.jsp">View Employee </a></td>
                        </tr>
                        
                       
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/item_preview.jsp">Preview Store Item</a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/view_received_item.jsp">View Distributed Item</a></td>
                        </tr>
                        
                       
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/employee_status.jsp">Employee Status</a></td>
                        </tr>
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/net_stock_preview.jsp">Net Stock Item</a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/test_form.jsp">Test</a></td>
                        </tr>
                        
                        <tr>
                            <td> <a href="<?php echo base_url(); ?>store_category/test_form_1.jsp">Test_1</a></td>
                        </tr>
                        
                    </table>
                    <?php endif; ?>
                    
                    
                </div>

                <div class="content">

                    <?php echo $main_content; ?>

                </div>

                <div class="content_right"></div>



            </div>
                <div class="clr"  > </div>
            <div id="footer" >
                
                <p style="float: left; padding-left: 20px"> All copyright reserved by PHIS</p>

                <p style="float: right; text-align: left; padding-right: 20px;">Developed by PHIS IT</p>

            </div>




            <div class="clr"  > </div>



    </body>
</html>