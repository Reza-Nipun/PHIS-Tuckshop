-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 31, 2015 at 11:08 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_phis_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_login`
--

CREATE TABLE IF NOT EXISTS `tbl_admin_login` (
  `admin_id` int(3) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  `role` tinyint(1) NOT NULL COMMENT 'administrator=1, user=2, viewer=3',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_admin_login`
--

INSERT INTO `tbl_admin_login` (`admin_id`, `admin_name`, `admin_email_address`, `admin_password`, `role`) VALUES
(1, 'Suman Sen', 'suman.sen@pledgeharbor.org', 'phsa8115417', 1),
(2, 'habiba', 'habiba@phsa.com', '123456', 2),
(3, 'sudeb', 'sudeb.das@pledgeharbor.org', '123456', 3),
(4, 'Rahul Karim', 'rahul.karim@pledgeharbor.org', '123456', 1),
(5, 'Mizanur Rahman', 'mizanur.rahman@pledgeharbor.org', 'mizan@123', 1),
(6, 'test1', 'test1@phis.com', '123456', 1),
(7, 'test2', 'test2@phis.com', '123456', 2),
(8, 'test3', 'test3@phis.com', '123456', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_defect_item`
--

CREATE TABLE IF NOT EXISTS `tbl_defect_item` (
  `defect_id` int(7) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `item_id` int(2) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(4) NOT NULL,
  `defect_type` text NOT NULL,
  `item_remarks` text NOT NULL,
  PRIMARY KEY (`defect_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_defect_item`
--

INSERT INTO `tbl_defect_item` (`defect_id`, `date`, `item_id`, `item_specification`, `item_quantity`, `defect_type`, `item_remarks`) VALUES
(1, '2014-08-05', 1, 'dell Vostro', 1, 'PC not Support', 'Used Movie night Laptop '),
(2, '2014-08-05', 2, 'Computer Lab PC', 2, 'PC not Support', 'Hard drive Not support'),
(3, '2014-08-05', 3, 'Hitachi projector', 3, 'Font not support', 'Server Room'),
(4, '2014-08-05', 6, 'Speaker Secretive', 5, 'Sound system not support', 'Class Room'),
(5, '2014-08-05', 8, 'Grandstream', 3, 'Living Room ', 'Brand:Grandstream'),
(6, '2014-08-05', 17, 'Power tree', 5, 'UPS', 'all campus'),
(7, '2014-08-05', 24, 'A4 Tech', 3, 'not properly worked', 'Rasel,Sheen,Liabry'),
(8, '2014-08-05', 2, 'Desktop core i3', -1, 'PC Complete Work', 'Computer lab pc'),
(9, '2014-11-20', 15, 'Micro ups 2000va ', 1, 'not properly worked', 'Circuit problems '),
(10, '2014-11-29', 2, 'Core i3,Hard disk 500GB ,Ram-2GB', 1, 'not properly worked', 'Hardisk Problem ');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_distribute`
--

CREATE TABLE IF NOT EXISTS `tbl_distribute` (
  `distribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `receiver_id` varchar(50) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `item_id` varchar(25) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`distribute_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=293 ;

--
-- Dumping data for table `tbl_distribute`
--

INSERT INTO `tbl_distribute` (`distribute_id`, `date`, `receiver_id`, `designation`, `item_id`, `item_specification`, `item_quantity`, `remarks`) VALUES
(1, '2014-08-05', '13', 'CAS Coordinator ', '1', 'Core i3', 1, '0'),
(2, '2014-08-05', '13', 'CAS Coordinator ', '3', 'Hitachi CP-X2521', 1, '0'),
(3, '2014-09-14', '13', 'CAS Coordinator ', '5', 'HP laserjet', 1, '0'),
(4, '2014-09-08', '13', 'CAS Coordinator ', '6', 'Speaker Creative', 1, '0'),
(5, '2014-08-05', '17', 'Middle School Mathematics', '1', 'Dell laptop core i3', 1, '0'),
(6, '2014-08-05', '17', 'Middle School Mathematics', '3', 'Projector CP-X2521WN', 1, '0'),
(7, '2014-08-05', '17', 'Middle School Mathematics', '5', 'Lajerjet HP 1102', 1, '0'),
(8, '2014-08-05', '17', 'Middle School Mathematics', '4', 'Creative 2:1', 1, '0'),
(9, '2014-08-05', '17', 'Middle School Mathematics', '24', 'A4 tech keboard', 1, '0'),
(10, '2014-08-16', '49', 'Faculty', '1', 'Inspiron 3442', 1, '0'),
(11, '2014-08-19', '49', 'Faculty', '3', 'projector CP-x2521WN', 1, '0'),
(12, '2014-08-19', '49', 'Faculty', '5', ' laserjet HP-1102 ', 1, '0'),
(13, '2014-08-19', '49', 'Faculty', '6', 'creative 2:1', 1, '0'),
(14, '2014-08-25', '49', 'Faculty', '25', '5 Port Multiplug', 1, '0'),
(15, '2014-09-04', '48', 'Faculty', '26', 'Nokia 105 witg charger', 1, '0'),
(16, '2014-08-12', '5', 'VP', '8', 'Grandstream GXP285', 1, '0'),
(17, '2014-08-12', '5', 'VP', '5', 'Lajerjet HP 1102', 1, '0'),
(18, '2014-08-12', '5', 'VP', '1', 'inspiron 3442', 1, '0'),
(19, '2014-08-12', '5', 'VP', '25', 'Multiplug 5 port', 2, '0'),
(20, '2014-08-14', '5', 'VP', '6', 'creative 2:1', 1, '0'),
(21, '2014-08-14', '5', 'VP', '2', 'Desktop Core i3', 1, '0'),
(22, '2014-08-18', '5', 'VP', '17', 'Power Tree', 1, '0'),
(23, '2014-08-18', '5', 'VP', '3', 'Projector CP-x2530WN', 1, '0'),
(24, '2014-08-18', '5', 'VP', '27', 'VGA Long Cable', 1, '0'),
(25, '2014-08-08', '56', 'Teacher Assistant & HM', '1', 'Duel core', 1, '0'),
(26, '2014-08-08', '56', 'Teacher Assistant & HM', '28', 'A4 Tech', 1, '0'),
(27, '2014-09-08', '56', 'Teacher Assistant & HM', '29', 'Dell', 1, '0'),
(28, '2014-09-22', '56', 'Teacher Assistant & HM', '8', 'Grandstream GXP1165', 1, '0'),
(29, '2014-09-22', '56', 'Teacher Assistant & HM', '30', 'Havit', 1, '0'),
(30, '2014-08-31', '51', 'Assistant Faculty', '1', 'Dell Vostro 1450', 1, '0'),
(31, '2014-08-17', '51', 'Assistant Faculty', '3', 'Optoma', 1, '0'),
(32, '2014-08-17', '51', 'Assistant Faculty', '31', 'HP P1102', 1, '0'),
(33, '2014-08-17', '51', ' Assistant Faculty', '6', 'Creative sub2:1', 1, '0'),
(34, '2014-08-25', '51', ' Assistant Faculty', '25', '5 port', 1, '0'),
(35, '2014-08-31', '51', ' Assistant Faculty', '28', 'A4 tech', 1, '0'),
(36, '2014-08-28', '54', 'Imam & House Master ', '1', 'Fojitsu LH510', 1, '0'),
(37, '2014-08-28', '54', 'Imam & House Master ', '28', 'A4 tech', 1, '0'),
(38, '2014-08-28', '54', 'Imam & House Master ', '24', 'A4 tech', 1, '0'),
(39, '2014-08-27', '54', 'Imam & House Master ', '3', 'Hitachi CP-X2521', 1, '0'),
(40, '2014-08-27', '54', 'Imam & House Master ', '6', 'Creative sub2:1', 1, '0'),
(41, '2014-08-17', '20', '  Bangla Faculty', '1', 'Latitude E5520', 1, '0'),
(42, '2014-08-17', '20', '  Bangla Faculty', '3', 'Optoma', 1, '0'),
(43, '2014-08-17', '20', '  Bangla Faculty', '31', 'HP P1102', 1, '0'),
(44, '2014-08-17', '20', '  Bangla Faculty', '6', 'Creative sub2:1', 1, '0'),
(45, '2014-08-17', '21', 'Bangla Faculty', '1', 'Latitude E5520', 1, '0'),
(46, '2014-08-17', '21', 'Bangla Faculty', '3', 'Optoma', 1, '0'),
(47, '2014-08-17', '21', '  Bangla Faculty', '31', 'HP P1102', 1, '0'),
(48, '2014-08-17', '21', 'Bangla Faculty', '6', 'Creative sub2:1', 1, '0'),
(49, '2014-08-17', '21', '  Bangla Faculty', '8', 'Grandstream', 1, '0'),
(50, '2014-09-17', '21', 'Bangla Faculty', '25', '5port', 1, '0'),
(51, '2014-08-17', '16', 'Middle School English & D', '1', 'core i3', 1, '0'),
(52, '2014-08-17', '16', 'Middle School English & D', '3', 'CP-X2521', 1, '0'),
(53, '2014-08-17', '16', 'Middle School English & D', '31', 'HP P1102', 1, '0'),
(54, '2014-08-17', '16', 'Middle School English & D', '6', 'Creative sub2:1', 1, '0'),
(55, '2014-08-23', '16', 'Middle School English & D', '26', 'Nokia', 1, '0'),
(56, '2014-08-21', '12', ' Science Department Coord', '1', 'Core i3', 1, '0'),
(57, '2014-08-21', '12', ' Science Department Coord', '3', 'CP-X2521', 1, '0'),
(58, '2014-08-21', '12', ' Science Department Coord', '31', 'HP P1102', 1, '0'),
(59, '2014-08-21', '12', ' Science Department Coord', '6', 'Creative sub2:1', 1, '0'),
(60, '2014-08-21', '12', ' Science Department Coord', '28', 'A4 tech', 1, '0'),
(61, '2014-08-21', '12', ' Science Department Coord', '25', '5port', 2, '0'),
(62, '2014-08-17', '11', 'Faculty & Social Studies ', '1', 'Core i3', 1, '0'),
(63, '2014-08-17', '11', 'Faculty & Social Studies ', '3', 'CP-X2521', 1, '0'),
(64, '2014-08-17', '11', 'Faculty & Social Studies ', '31', 'HP P1102', 1, '0'),
(65, '2014-08-17', '11', 'Faculty & Social Studies ', '6', 'Creative sub2:1', 1, '0'),
(66, '2014-08-17', '11', 'Faculty & Social Studies ', '25', '5ports', 1, '0'),
(67, '2014-08-23', '11', 'Faculty & Social Studies ', '25', '5ports', 1, '0'),
(68, '2014-08-18', '10', ' Faculty & Integrated Sub', '1', 'core i3', 1, '0'),
(69, '2014-08-18', '10', ' Faculty & Integrated Sub', '3', 'CP-X2521', 1, '0'),
(70, '2014-08-18', '10', ' Faculty & Integrated Sub', '6', 'Creative sub2:1', 1, '0'),
(71, '2014-08-18', '10', ' Faculty & Integrated Sub', '25', '5ports', 1, '0'),
(72, '2014-08-04', '14', 'Middle School Math Coordi', '3', 'CP-X2521', 1, '0'),
(73, '2014-08-04', '14', 'Middle School Math Coordi', '31', 'HP P1102', 1, '0'),
(74, '2014-08-04', '14', 'Middle School Math Coordi', '6', 'Creative sub2:1', 1, '0'),
(75, '2014-08-04', '14', 'Middle School Math Coordi', '25', '5ports', 2, '0'),
(76, '2014-08-04', '14', 'Middle School Math Coordi', '26', 'Nokia N1280', 1, '0'),
(77, '2014-08-04', '14', 'Middle School Math Coordi', '1', 'Core i3', 1, '0'),
(78, '2014-08-17', '15', 'Physical Education Coordi', '1', 'core i3', 1, '0'),
(79, '2014-08-17', '15', 'Physical Education Coordi', '3', 'CP-X2521', 1, '0'),
(80, '2014-08-17', '15', 'Physical Education Coordi', '6', 'Creative sub2:1', 1, '0'),
(81, '2014-08-17', '15', 'Physical Education Coordi', '31', 'HP P1102', 1, '0'),
(82, '2014-08-25', '15', 'Physical Education Coordi', '24', 'External', 1, '0'),
(83, '2014-08-16', '6', 'Curriculum/IB Coordinator', '1', 'Latitude', 1, '0'),
(84, '2014-08-16', '6', 'Curriculum/IB Coordinator', '31', 'HP P1102', 1, '0'),
(85, '2014-08-16', '6', 'Curriculum/IB Coordinator', '8', 'GXP-280', 1, '0'),
(86, '2014-08-16', '6', 'Curriculum/IB Coordinator', '25', '5ports', 1, '0'),
(87, '2014-08-20', '6', 'Curriculum/IB Coordinator', '3', 'CP-X2521', 1, '0'),
(88, '2014-08-20', '6', 'Curriculum/IB Coordinator', '6', 'Creative sub2:1', 1, '0'),
(89, '2014-08-27', '6', 'Curriculum/IB Coordinator', '25', '5ports', 1, '0'),
(90, '2014-08-27', '6', 'Curriculum/IB Coordinator', '4', 'Cannon lide110', 1, '0'),
(91, '2014-08-27', '8', 'Head Librarian', '1', 'Dell-1450', 1, '0'),
(92, '2014-08-27', '8', 'Head Librarian', '8', 'Grandstream', 1, '0'),
(93, '2014-08-27', '8', 'Head Librarian', '24', 'A4 tech', 1, '0'),
(94, '2014-08-27', '8', 'Head Librarian', '32', 'External 500GB', 1, '0'),
(95, '2014-08-26', '19', 'Faculty', '1', 'core i3', 1, '0'),
(96, '2014-08-18', '22', 'Faculty  Math & Physics', '1', 'Fujitsu LH-530', 1, '0'),
(97, '2014-08-18', '22', 'Faculty  Math & Physics', '3', 'CP-X2521', 1, '0'),
(98, '2014-08-18', '22', 'Faculty  Math & Physics', '31', 'HP P1102', 1, '0'),
(99, '2014-08-18', '22', 'Faculty  Math & Physics', '28', 'A4 tech', 1, '0'),
(100, '2014-08-31', '7', 'Faculty, Math', '1', 'core i3', 1, '0'),
(101, '2014-08-31', '7', 'Faculty, Math', '3', 'CP-X2521', 1, '0'),
(102, '2014-08-31', '7', 'Faculty, Math', '31', 'HP P1102', 1, '0'),
(103, '2014-08-31', '7', 'Faculty, Math', '6', 'Microlab sub2:1', 1, '0'),
(104, '2014-08-31', '7', 'Faculty, Math', '25', '5ports', 1, '0'),
(105, '2014-08-31', '7', 'Faculty, Math', '28', 'A4 tech', 1, '0'),
(106, '2014-08-31', '7', 'Faculty, Math', '33', 'Smartboard', 1, '0'),
(107, '2014-08-14', '9', 'English teacher for the s', '1', 'Core i3', 1, '0'),
(108, '2014-08-14', '9', 'English teacher for the s', '29', 'Dell', 1, '0'),
(109, '2014-08-17', '9', 'English teacher for the s', '3', 'CP-DX300', 1, '0'),
(110, '2014-08-17', '9', 'English teacher for the s', '31', 'HP P1102', 1, '0'),
(111, '2014-08-17', '9', 'English teacher for the s', '6', 'Microlab sub2:1', 1, '0'),
(112, '2014-08-18', '9', 'English teacher for the s', '27', 'For Laptop', 1, '0'),
(113, '2014-08-18', '9', 'English teacher for the s', '34', '2-Miter', 1, '0'),
(114, '2014-08-16', '18', 'Faculty Art ', '1', 'core i3', 1, '0'),
(115, '2014-08-16', '18', 'Faculty Art ', '29', 'Dell', 1, '0'),
(116, '2014-08-17', '18', 'Faculty Art ', '3', 'CP-DX300', 1, '0'),
(117, '2014-08-17', '18', 'Faculty Art ', '31', 'HP P1102', 1, '0'),
(118, '2014-08-17', '18', 'Faculty Art ', '6', 'Microlab sub2:1', 1, '0'),
(119, '2014-08-16', '58', 'Faculty', '1', 'core i3', 1, '0'),
(120, '2014-08-16', '58', 'Faculty', '29', 'Dell', 1, '0'),
(121, '2014-08-17', '58', 'Faculty', '31', 'HP P1102', 1, '0'),
(122, '2014-08-17', '58', 'Faculty', '3', 'CP-DX300', 1, '0'),
(123, '2014-08-17', '58', 'Faculty', '6', 'Microlab sub2:1', 1, '0'),
(124, '2014-08-17', '58', 'Faculty', '25', '5-ports', 1, '0'),
(125, '2014-08-14', '57', 'Dorm superviser', '1', 'Core i3', 1, '0'),
(126, '2014-08-18', '57', 'Dorm superviser', '3', 'CP-X2521', 1, '0'),
(127, '2014-08-18', '57', 'Dorm superviser', '31', 'HP P1102', 1, '0'),
(128, '2014-08-18', '57', 'Dorm superviser', '6', 'Microlab sub2:1', 1, '0'),
(129, '2014-08-05', '57', 'Dorm superviser', '31', 'HPlaserjet', 1, '0'),
(130, '2014-08-05', '13', 'CAS Coordinator ', '31', 'HP Laserjet', 1, '0'),
(131, '2014-08-05', '17', 'Middle School Mathematics', '31', 'HP Laserjet', 1, '0'),
(132, '2014-08-05', '49', 'Faculty', '31', 'HP Laserjet', 1, '0'),
(133, '2014-08-05', '5', 'VP', '31', 'HP Laserjet', 1, '0'),
(134, '2014-08-05', '10', ' Faculty & Integrated Sub', '31', 'HP Laserjet', 1, '0'),
(136, '2014-08-05', '32', ' Residence Doctor', '31', 'HP Laserjet', 1, '0'),
(137, '2014-08-05', '11', 'Faculty Manager', '31', 'HP laserjet', 1, '0'),
(138, '2014-08-05', '48', ' Cafeteria Manager', '31', 'HP Laserjet', 1, '0'),
(139, '2014-08-05', '46', 'Store Keeper', '31', 'HP laserjet', 1, '0'),
(140, '2014-08-05', '47', ' Officer, Administration', '31', 'HP Laserjet', 1, '0'),
(141, '2014-08-05', '4', 'SDP', '6', 'Microlab', 1, '0'),
(142, '2014-08-05', '1', 'IT Manager', '9', 'Netgear switch 8 port', 14, '0'),
(143, '2014-08-05', '1', 'IT Manager', '22', 'Netgear wirless 300', 5, '0'),
(144, '2014-08-05', '1', 'IT Manager', '23', 'Netgear Wireless 750', 1, '0'),
(145, '2014-08-05', '1', 'IT Manager', '11', 'Netgear switch 24 port', 2, '0'),
(146, '2014-08-05', '65', 'offce adnistrator for pri', '8', 'Grandstream', 1, '0'),
(147, '2014-08-05', '65', 'offce adnistrator for pri', '4', 'HP scanjet 200', 1, '0'),
(148, '2014-08-05', '65', 'offce adnistrator for pri', '6', 'Havit', 1, '0'),
(149, '2014-08-05', '65', 'offce adnistrator for pri', '1', 'Dell  inspiron-3442', 1, '0'),
(150, '2014-08-05', '65', 'offce adnistrator for pri', '8', 'Grandst', 1, '0'),
(151, '2014-08-05', '65', 'offce adnistrator for pri', '31', 'HP Printer', 1, '0'),
(152, '2014-08-05', '65', 'offce adnistrator for pri', '25', '8 port', 1, '0'),
(153, '2014-08-05', '65', 'offce adnistrator for pri', '24', 'A4 Tech', 1, '0'),
(154, '2014-08-05', '65', 'offce adnistrator for pri', '28', 'A4 Mouse', 1, '0'),
(155, '2014-08-05', '65', 'offce adnistrator for pri', '29', 'Dell Bag', 1, '0'),
(156, '2014-08-05', '1', 'IT Manager', '18', 'IP Camera', 40, '0'),
(157, '2014-08-05', '46', 'Officer, General Administ', '4', 'canon 110', 1, '0'),
(158, '2014-08-05', '46', 'Officer, General Administ', '24', 'A4 Tech', 1, '0'),
(159, '2014-08-05', '46', 'Officer, General Administ', '8', 'Grandstream', 1, '0'),
(160, '2014-08-05', '46', 'Officer, General Administ', '2', 'Desktop cori3', 1, '0'),
(161, '2014-08-05', '46', 'Officer, General Administ', '17', 'UPS 750 VA, Power tree ', 1, '0'),
(162, '2014-08-05', '48', ' Cafeteria Manager', '2', 'CPU:Cori3 RAM:2GB', 1, '0'),
(163, '2014-08-05', '48', ' Cafeteria Manager', '4', 'Canon 110', 1, '0'),
(164, '2014-08-05', '48', ' Cafeteria Manager', '8', 'Grandstem', 1, '0'),
(165, '2014-08-05', '61', ' Cafeteria Manager', '17', 'Power tree', 1, '0'),
(166, '2014-08-05', '30', 'Office Administrator (COO', '4', ' HP Scanjet G2410', 1, '0'),
(167, '2014-08-05', '4', 'SDP', '17', 'power Tree', 1, '0'),
(168, '2014-08-05', '30', 'Office Administrator (COO', '16', 'Micro Power', 1, '0'),
(170, '2014-08-05', '30', 'Office Administrator (COO', '21', 'network printer 1520', 1, '0'),
(171, '2014-08-05', '30', 'Office Administrator (COO', '20', 'HP Printer 2055', 1, '0'),
(172, '2014-08-05', '30', 'Office Administrator (COO', '2', 'Core i5, 1 TB HDD, samsung-22(2)" Monitor,', 1, '1 Extra monitor 22"'),
(173, '2014-08-05', '3', 'Jr. Officer, IT Administr', '4', 'HP Scanjet G2410', 1, '0'),
(174, '2014-08-05', '36', 'Faculty Manager', '4', 'Canon 110 ', 1, '0'),
(175, '2014-08-05', '66', 'staff', '4', 'canon 110', 1, '0'),
(177, '2014-08-05', '30', 'Office Administrator (COO', '2', 'Duel core ', 1, '0'),
(178, '2014-08-05', '1', 'IT Manager', '22', 'Netgear Wireless 300', 1, '0'),
(179, '2014-08-05', '1', 'IT Manager', '14', 'Netgear Wireless 150', 32, '0'),
(180, '2014-08-05', '2', 'Officer, IT Administratio', '20', 'HP Laserjet 2055', 1, '0'),
(181, '2014-08-05', '4', 'SD (COO)', '8', 'Grandstream', 1, '0'),
(182, '2014-08-05', '30', 'Office Administrator (COO', '8', 'Grandstream', 1, '0'),
(183, '2014-08-05', '66', 'staff', '8', 'Grandstream', 1, '0'),
(184, '2014-08-05', '20', '  Bangla Faculty', '8', 'Grandstream', 1, '0'),
(185, '2014-08-05', '32', ' Residence Doctor', '8', 'Grandstream', 1, '0'),
(186, '2014-08-05', '32', ' Residence Doctor', '8', 'Grandstream Living Room', 1, '0'),
(187, '2014-08-05', '67', 'staff', '8', 'Grandstream', 1, '0'),
(188, '2014-08-05', '47', ' Officer, Administration', '8', 'Grandstream', 1, '0'),
(189, '2014-08-05', '36', 'Facility Manager', '8', 'Grandstream', 1, '0'),
(190, '2014-08-05', '68', 'Waiter', '8', 'Grandstream', 1, '0'),
(191, '2014-08-05', '69', 'Food', '8', 'Grandstream', 1, '0'),
(192, '2014-08-05', '48', ' Cafeteria Manager', '8', 'Grandstream ', 1, '0'),
(193, '2014-08-05', '70', 'Waiter', '8', 'Grandstream', 1, '0'),
(194, '2014-08-05', '71', 'Security', '8', 'Grandstream', 1, '0'),
(195, '2014-08-05', '72', 'Grund Floor', '8', 'Grandstream', 1, '0'),
(196, '2014-08-05', '73', 'Ground Floor 2', '8', 'Grandstream', 1, '0'),
(197, '2014-08-05', '74', 'Dorm-2', '8', 'Grandstream', 1, '0'),
(198, '2014-08-05', '30', 'Office Administrator (COO', '8', 'Grandstream', 1, '0'),
(199, '2014-08-05', '36', 'Facility Manager', '8', 'Grandstream', 1, '0'),
(200, '2014-08-05', '55', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(201, '2014-08-05', '75', ' Assistant Faculty', '8', 'Grandstream', 1, '0'),
(202, '2014-08-05', '53', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(203, '2014-08-05', '51', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(204, '2014-08-05', '42', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(205, '2014-08-05', '45', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(207, '2014-08-05', '52', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(208, '2014-08-05', '44', 'Teacher Assistant and Hou', '8', 'Grandstream', 1, '0'),
(209, '2014-08-05', '1', 'IT Manager', '8', 'Grandstream', 1, '0'),
(210, '2014-08-05', '2', 'Officer, IT Administratio', '8', 'Grandstream', 1, '0'),
(211, '2014-08-05', '6', 'Curriculum/IB Coordinator', '17', 'power tree', 1, '0'),
(212, '2014-08-05', '6', 'Curriculum/IB Coordinator', '24', 'A4 Tech', 1, '0'),
(213, '2014-08-05', '1', 'IT Manager', '22', 'Netgear wireless router 300', 1, '0'),
(214, '2014-08-05', '1', 'IT Manager', '14', 'Netgear wireless router', -1, '0'),
(215, '2014-08-05', '6', 'Curriculum/IB Coordinator', '2', 'Dell Monitor,core i3,Ram-2GB,Hardisk-500GB', 1, '0'),
(216, '2014-08-05', '6', 'Curriculum/IB Coordinator', '28', 'A4 Tech', 1, '0'),
(217, '2014-08-05', '52', 'Teacher Assistant and Hou', '1', 'Core i3 ', 1, '0'),
(218, '2014-08-05', '53', 'Teacher Assistant and Hou', '1', 'Core i3 laptop', 1, '0'),
(219, '2014-08-05', '76', 'Student user', '2', 'computer lab, core i3 Desktop pc', 20, '0'),
(220, '2014-08-05', '76', 'Student user', '2', 'Duel core', 1, '0'),
(221, '2014-08-05', '8', 'Head Librarian', '2', 'Dell Monitor 22" core i3', 2, '0'),
(222, '2014-08-05', '32', ' Residence Doctor', '2', 'Core i3', 1, '0'),
(223, '2014-08-05', '66', 'staff', '2', 'Core i3 samsung', 1, '0'),
(224, '2014-08-05', '4', 'SD (COO)', '2', 'core i3 ', 1, '0'),
(225, '2014-08-05', '3', 'Jr. Officer, IT Administr', '2', 'core i3', 1, '0'),
(226, '2014-08-05', '2', 'Officer, IT Administratio', '2', 'core i3', 1, '0'),
(227, '2014-08-05', '41', ' Cricket Coach', '2', 'core i3 ', 1, '0'),
(228, '2014-08-05', '77', 'Server room', '2', 'core i3', 3, '0'),
(229, '2014-08-05', '36', 'Facility Manager', '2', 'core i3', 1, '0'),
(230, '2014-08-05', '37', ' Junior Office, Administr', '2', 'core i3', 1, '0'),
(231, '2014-08-05', '39', ' Junior Officer, Administ', '2', 'core i3', 1, '0'),
(232, '2014-08-05', '1', 'IT Manager', '22', 'Netgear wireless router', 1, '0'),
(233, '2014-08-05', '36', 'Facility Manager', '23', 'power tree', 1, '0'),
(234, '2014-08-05', '37', ' Junior Office, Administr', '17', 'Power tree', 1, '0'),
(235, '2014-08-05', '39', ' Junior Officer, Administ', '17', 'Power Tree', 1, '0'),
(236, '2014-08-05', '1', 'IT Manager', '10', 'Netgear switch 16 port', 18, '0'),
(237, '2014-08-05', '1', 'IT Manager', '10', 'Netgear switch 16 port', -1, '0'),
(238, '2014-08-05', '1', 'IT Manager', '10', 'Netgear switch 16 port', 1, '0'),
(239, '2014-10-29', '32', ' Residence Doctor', '35', 'Toshiba ,Hard disk 500GB', 1, 'Use doctor room PC, Previous one is defect.'),
(240, '2014-10-29', '1', 'IT Manager', '36', 'Laptop charger Movie night', 1, '0'),
(241, '2014-10-29', '1', 'IT Manager', '37', 'Fujitsu Laptop charger', 1, '0'),
(242, '2014-08-05', '1', 'IT Manager', '23', 'Netgear Router 750', -1, '0'),
(243, '2014-10-30', '12', ' Lab Assistant and House ', '25', 'Multiplug 6port tow pase', 2, '0'),
(244, '2014-10-30', '42', ' Assistant Coach and Hous', '25', 'multiplug 5 Port', 1, '0'),
(245, '2014-10-30', '41', ' Football Coach', '25', 'Multiplug 5 port', 1, '0'),
(246, '2014-10-30', '40', ' Cricket Coach', '25', 'multiplug 5port', 1, '0'),
(247, '2014-10-30', '40', ' Cricket Coach', '17', 'Power tree 750VA', 1, '0'),
(248, '2014-10-30', '77', 'Server room', '35', 'Toshiba, 500 GB Hard disk', 1, 'Use in Camera Server PC. Previous one is defect'),
(249, '2014-10-30', '77', 'Server room', '10', 'Netgear switch 16 port server room', 1, '0'),
(251, '2014-10-30', '40', ' Cricket Coach', '2', 'core i3 ,500 GB Hard disk Ram 2GB', 1, '0'),
(252, '2014-10-30', '42', ' Assistant Coach and Hous', '2', 'Core i3, 500GB Hard disk, Ram GB', 1, '0'),
(253, '2014-10-30', '12', ' Lab Assistant and House ', '2', 'Samsung 19" two pcs and Desktop pc Asus core i3 ,Hardisk 500GB Tow pcs,  ', 2, '0'),
(254, '2014-08-05', '36', 'Facility Manager', '31', 'HP laserjet P1102', 1, '0'),
(255, '2014-11-01', '57', 'Dorm superviser', '6', 'Microlab 2:1', 1, '0'),
(256, '2014-11-11', '79', 'Office administrator(Dr.L', '2', 'Core i3,Hardisk 500GB,Ram-4GB', 1, '0'),
(257, '2014-11-11', '79', 'Office administrator(Dr.L', '31', 'HP Laserjet P1102', 1, '0'),
(258, '2014-11-11', '79', 'Office administrator(Dr.L', '17', 'Power tree 750VA', 1, '0'),
(259, '2014-11-09', '19', 'Faculty', '31', 'HP Laserjet P1102', 1, '0'),
(260, '2014-08-08', '15', 'Physical Education Coordi', '25', 'Multiplug 5 port', 1, '0'),
(261, '2014-10-05', '65', 'Offce Adnistrator(Princip', '2', 'Dell monitor 19" Cpu:core i3 Hardisk 500GB', 1, '0'),
(262, '2014-10-10', '65', 'Offce Adnistrator(Princip', '17', 'Power Tree UPS 750VA', 1, '0'),
(263, '2014-11-04', '80', 'Assistant Coach & House m', '2', 'Cpu:dell vostro 460, Hardisk \r\n500GB', 1, '0'),
(264, '2014-08-08', '76', 'Student user', '33', 'Smartboard for Library room', 1, '0'),
(265, '2014-08-08', '14', 'Middle School Math Coordi', '33', 'Smartboard for class room', 1, '0'),
(266, '2014-08-08', '19', 'Faculty', '33', 'Smartboard for Class room', 1, '0'),
(267, '2014-08-08', '17', 'Middle School Mathematics', '33', 'Smartboard for class room', 1, '0'),
(268, '2014-11-30', '8', 'Head Librarian', '2', 'Monitor 22" Dell, DH61WW Core i3', 1, '0'),
(269, '2014-12-30', '8', 'Head Librarian', '17', 'Power tree 750VA for library office -3pcs', 3, '0'),
(270, '2014-08-08', '32', ' Residence Doctor', '17', 'Power tree 750VA', 1, '0'),
(271, '2014-08-08', '66', 'Staff', '17', 'power tree 750Va for Teachers lounge', 1, '0'),
(272, '2014-12-01', '48', ' Cafeteria Manager', '6', 'Creative speakers', 1, '0'),
(273, '2014-08-08', '1', 'IT Manager', '16', 'Micro UPS 1500VA For Server Room', 3, '0'),
(274, '2014-08-08', '1', 'IT Manager', '16', 'Micro UPS 1500VA For server Room', 1, '0'),
(275, '2014-08-08', '76', 'Student user', '16', 'Micro UPS 1500VA For Computer lab', 1, '0'),
(276, '2014-08-08', '73', 'Ground Floor 2', '16', 'Micro UPS 1500VA For Dorm-2 Ground Floor', 1, '0'),
(277, '2014-08-08', '81', 'Faculty', '16', 'Micro UPS 1500VA For Teachers Quarters', 1, '0'),
(278, '2014-08-08', '76', 'Student user', '19', 'Micro UPS 1000VA for Computer Lab', 4, '0'),
(279, '2014-08-08', '72', 'Grund Floor', '15', 'Micro UPS 2000VA For Dorm-1 ground floor', 1, '0'),
(280, '2014-08-08', '1', 'IT Manager', '15', 'Micro UPS 2000VA For Server Room', 2, '0'),
(281, '2014-08-08', '77', 'Dorm Levale -4', '8', 'Grandstream GXP285', 1, '0'),
(282, '2014-11-05', '51', 'Assistant Faculty', '28', 'A4 Tech mouse', 1, '0'),
(283, '2014-11-01', '83', 'Teacher Assistant and Hou', '1', 'Dell Vostro 1450', 1, '0'),
(284, '2014-11-01', '83', 'Teacher Assistant and Hou', '28', 'A4 Tech Mouse', 1, '0'),
(285, '2014-11-20', '84', 'CAS Coordinator ', '3', 'Projector Optoma', 1, '0'),
(286, '2014-11-20', '84', 'CAS Coordinator ', '31', 'HP laserjet P1102', 1, '0'),
(287, '2014-11-20', '84', 'CAS Coordinator ', '6', 'Creative speaker', 1, '0'),
(288, '2014-11-20', '84', 'CAS Coordinator ', '25', 'Multiplug 5 port', 1, '0'),
(289, '2014-11-01', '83', 'Teacher Assistant and Hou', '8', 'Grandstream GXP285', 1, '0'),
(290, '2014-11-01', '57', 'Dorm superviser', '8', 'Grandstream GXP285', 1, '0'),
(291, '2014-12-04', '75', 'Assistant Faculty', '25', '5 port Multiplug', 1, '0'),
(292, '2015-02-23', '44', 'Officer Academic Admin.', '47', 'blue', 4, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `employee_id` int(3) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `employee_status` tinyint(1) NOT NULL COMMENT 'employee_status_Active=1, Employee_Status_inactive=0',
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=87 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`employee_id`, `employee_name`, `designation`, `employee_status`) VALUES
(1, 'Rahul Karim', 'IT Manager', 1),
(2, 'Suman Sen', 'Officer, IT Administratio', 1),
(3, 'Mizanur Rahman', 'Jr. Officer, IT Administr', 1),
(4, 'Dr. John R. Jenckes ', 'SD (COO)', 1),
(5, 'Christopher R. Manning ', 'Principal', 1),
(6, 'Lalima Jenckes', 'Curriculum/IB Coordinator', 1),
(7, 'Mery Ann Lopez Labastian', 'Faculty, Math', 1),
(8, ' Sampathkumar', 'Head Librarian', 1),
(9, 'Samantha Linehan', 'English teacher for the s', 1),
(10, 'Bridget Hannu', ' Faculty & Integrated Sub', 1),
(11, 'Roy Hannu', 'Faculty & Social Studies ', 1),
(12, ' Devin Bennett', ' Science Department Coord', 1),
(13, ' Soumyabrata Mukherjee', 'CAS Coordinator ', 1),
(14, ' Rene Perry', 'Middle School Math Coordi', 1),
(15, ' Andy Perry', 'Physical Education Coordi', 1),
(16, ' Jimmy Bishop', 'Middle School English & D', 1),
(17, ' Julian Rodriguez', 'Middle School Mathematics', 1),
(18, 'Matthew Holman ', 'Faculty Art ', 1),
(19, 'Altynai Manning', 'Faculty', 1),
(20, ' Md. Salah Uddin Abir', '  Bangla Faculty', 1),
(21, 'Rano Sarker', 'Bangla Faculty', 1),
(22, 'Zubair Hossain', 'Faculty  Math & Physics', 1),
(23, 'Muniruzzaman Alam', ' Manager, Group Admin', 1),
(24, ' Rashed Ahmed', ' Manager, HR', 1),
(25, ' Muzibur Rahman', 'Manager, Finance ', 1),
(26, 'Md. Abu Hanif', 'Accounts Officer', 1),
(27, 'Sharif Hassan ', ' Officer, Administration', 1),
(28, ' Protity Shabnam', ' Junior Office, Administr', 1),
(29, '  Ms. Jareen Simin Raisa', ' Junior Officer, Administ', 1),
(30, 'Dewan Saifuddin Ahammad', 'Office Administrator (COO', 1),
(32, ' Dr. Md. Kamrul Islam', ' Residence Doctor', 1),
(33, ' Dr. Shanto', ' Residence Doctor', 1),
(34, 'Sudeb Chandra Das', ' Nurse', 1),
(35, ' Latifa Nargish', '  Nurse', 1),
(36, 'Rayhanul Hoque', 'Facility Manager', 1),
(37, ' Dulan Ukil', 'Junior Administrator', 1),
(38, 'Shabbib Hussain', 'Junior Administrator', 1),
(39, 'Seakh Mohammad Shihab', 'Junior Administrator', 1),
(40, ' Khandaker Imtiaz Ahmad', ' Cricket Coach', 1),
(41, 'Md. Monwar Hossain', ' Football Coach', 1),
(42, ' Mrinal Chandra Roy', 'Junior Development Coach', 1),
(44, 'Surovi Jahan', 'Officer Academic Admin.', 1),
(45, '  Mr. Rakib Hasan', ' Lab Assistant and House ', 1),
(46, 'Humayun Kabir Rasel', 'Officer, General Administ', 1),
(47, 'Kazi Habiba Akter', ' Officer, Administration', 1),
(48, ' Mohammed Shaheen', ' Cafeteria Manager', 1),
(49, 'Lisa Holmes', 'Faculty', 1),
(51, 'Abdul Kadir', 'Assistant Faculty', 1),
(52, 'Naheed Sultana', 'Teacher Assistant and Hou', 1),
(53, 'Md. Badiuzzaman', 'Teacher Assistant and Hou', 1),
(54, 'Abdur Rubb', 'Imam & House Master ', 1),
(55, ' Kamal Hossen', 'Teacher Assistant and Hou', 0),
(56, 'Arif Hossain', 'Teacher Assistant & HM', 1),
(57, 'Richard Parkany', 'Dorm superviser', 1),
(58, 'Jessica cudney', 'Faculty', 1),
(61, 'Mohammed Shaheen', 'Cafeteria Manager', 1),
(65, 'Hasib zaman', 'Offce Adnistrator(Princip', 1),
(66, 'teacher lunch', 'staff', 1),
(67, 'Public IP Phone', 'Staff', 1),
(68, 'Cafeteria', 'Waiter', 1),
(69, 'Kitchen', 'Food', 1),
(70, 'Tiffin Room', 'Waiter', 1),
(71, 'Main Gate', 'Security', 1),
(72, 'Dorm-1  Main Gate', 'Grund Floor', 1),
(73, 'Dorm-2 Main Gate', 'Ground Floor 2', 1),
(74, 'Laundry', 'Dorm-2', 1),
(75, 'Tahmid Ansari', 'Assistant Faculty', 1),
(76, 'Computer lab', 'Student user', 1),
(77, 'IT Office', 'Server room', 1),
(79, 'Shaugata hossain', 'Office administrator(Dr.L', 1),
(80, 'AFM Maruf', 'Assistant Coach & House m', 1),
(81, 'Teachers quarters', 'Faculty', 1),
(82, 'IT Office', 'Dorm Levale -4', 1),
(83, 'Zahirul Islam Khan', 'Teacher Assistant and Hou', 1),
(84, 'Mr. Soumyabrata Mukherjee', 'CAS Coordinator ', 1),
(85, 'Surovi', 'Officer Academic Admin.', 1),
(86, 'Naheed Sultana', 'Teacher ( Bangla)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_return`
--

CREATE TABLE IF NOT EXISTS `tbl_return` (
  `return_id` int(7) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `returner_id` varchar(32) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `item_id` int(3) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(4) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`return_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `tbl_return`
--

INSERT INTO `tbl_return` (`return_id`, `date`, `returner_id`, `designation`, `item_id`, `item_specification`, `item_quantity`, `remarks`) VALUES
(1, '2014-11-01', '57', 'Dorm superviser', 31, 'Printer HP laserjet p1102', 1, '0'),
(2, '2014-11-01', '57', 'Dorm superviser', 25, 'Multiplug 5port', 1, '0'),
(3, '2014-11-01', '57', 'Dorm superviser', 6, 'Microlab 2:1', 1, '0'),
(4, '2014-11-01', '57', 'Dorm superviser', 3, 'Projector CP-x2521', 1, '0'),
(5, '2014-11-24', '8', 'Head Librarian', 8, 'Grandstream GXP285', 1, '0'),
(6, '2014-11-19', '47', ' Officer, Administration', 31, 'HP Laserjet P1102', 1, '0'),
(7, '2014-11-01', '57', 'Dorm superviser', 8, 'Grandstream GXP285', 1, '0'),
(8, '2014-11-11', '76', 'Student user', 2, 'Computer lab Desktop core i3,4pcs\r\nless', 4, '0'),
(9, '2014-11-29', '76', 'Student user', 2, 'Dell Monitor 22" DH61WW Core i3', 1, '0'),
(10, '2014-11-05', '51', 'Assistant Faculty', 1, 'Dell Vostro 1450', 1, '0'),
(11, '2014-11-05', '51', 'Assistant Faculty', 0, 'Projector Optoma', 1, '0'),
(12, '2014-11-05', '51', 'Assistant Faculty', 0, 'HP laserjet P1102', 1, '0'),
(13, '2014-11-05', '51', 'Assistant Faculty', 0, ' creative Speaker', 1, '0'),
(14, '2014-11-05', '51', 'Assistant Faculty', 25, 'Multiplug 5port', 1, '0'),
(15, '2014-11-05', '51', 'Assistant Faculty', 8, 'Grandstream GXP285', 1, '0'),
(16, '2014-11-05', '51', 'Assistant Faculty', 3, 'Optoma ', 1, '0'),
(17, '2014-11-05', '51', 'Assistant Faculty', 28, 'A4 Tech Mouse', 1, '0'),
(18, '2014-11-05', '51', 'Assistant Faculty', 6, 'Creative Speaker 2:1', 1, '0'),
(19, '2014-11-05', '51', 'Assistant Faculty', 31, 'HP Laserjet P1102', 1, '0'),
(20, '2014-10-16', '55', 'Teacher Assistant and Hou', 8, 'Grandstream GXP285', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store_category`
--

CREATE TABLE IF NOT EXISTS `tbl_store_category` (
  `st_category_id` int(3) NOT NULL AUTO_INCREMENT,
  `st_category_name` varchar(25) NOT NULL,
  `st_category_description` text NOT NULL,
  PRIMARY KEY (`st_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

--
-- Dumping data for table `tbl_store_category`
--

INSERT INTO `tbl_store_category` (`st_category_id`, `st_category_name`, `st_category_description`) VALUES
(1, 'Laptop', 'Laptop for PHSA'),
(2, 'Desktop', 'Desktop for PHSA Student and Office'),
(3, 'Projector', 'For Projection'),
(4, 'Scanner', 'for Scan Document'),
(6, 'Speaker ', 'Creative 2:1'),
(8, 'IP Phone', 'Grandstream'),
(9, ' 8 Port Switch', 'Netgear'),
(10, '16 Port Switch', 'Netgear'),
(11, '24 Port Switch', 'Netgear'),
(14, 'Router 150', 'N150 Wireless Router'),
(15, 'UPS 2000 VA', 'Micro Power'),
(16, 'UPS 1500 VA', 'Micro Power'),
(17, 'UPS 750VA', 'Power Tree'),
(18, 'CC Camera', 'CC Camera Campus'),
(19, 'UPS 100VA', 'Power Tree'),
(20, 'Printer 2055', 'HP Network Printer'),
(21, 'Printer 1520', 'HP color printer'),
(22, 'Router 300', 'N300 Wirelss '),
(23, 'Router 750', 'N750 Wireless'),
(24, 'Keyboard ', 'A4 Tech keyboard'),
(25, 'Multiplug', '5 port'),
(26, 'Mobile Phone', 'Nokia 105 With charger'),
(27, 'VGA Cable', 'VGA Long '),
(28, 'Mouse', 'A4 Tech'),
(29, 'Laptop bag', 'Dell'),
(30, 'Headphone', 'Havit'),
(31, 'Printer HP P1102', 'HP Laser Jet P1102 Black and White Printer'),
(32, 'External Hard disk', 'External 500GB'),
(33, 'Smartboard', 'Smartboard'),
(34, 'HDMI cable', 'HDMI cable'),
(35, 'Hard Disk', 'Internal Desktop Hard Disk'),
(37, 'Laptop Charger', 'Fujitsu laptop Charger'),
(38, 'Kitkat', '50 gram pack'),
(39, 'Oreo', '40 gram pack'),
(40, 'Adhesive', '9*13/ 19*38/32*64'),
(41, 'Agenda ( pc)', 'white ( PHSA)'),
(42, 'Attendance register', '100pg ( big) '),
(43, 'Anticutter', 'deli - 2031 ( 26 blades)'),
(44, 'Anticutter', 'Deli no - 2041 ( 16 blades)'),
(45, 'Attendance register', '150 pg'),
(46, 'Alphabet', ' A only'),
(47, 'Art paper', ' big size'),
(48, 'Brush', 'black wooden 1/2''''/paste wooden no 16/brown no 10/ sponge'),
(49, 'Bangla copy', ' 120pg'),
(50, 'Bangla loose sheet', '200pg'),
(51, 'Bangla loose sheet', '444 pg'),
(53, 'Basket ', 'red ( medium size)'),
(54, 'Binder clip ', '1'''' ( diamond)'),
(55, 'Binder clip ', 'Diamond - 2 '''''),
(56, 'Binder clip ( box)', '1 - 5/9'''''),
(57, 'Binder clip ( box)', 'all types extra'),
(58, 'Battery', 'GP ( Scientific calculator)'),
(59, 'Bucket big - plastic blue', ' big - plastic blue'),
(60, 'Correction pen', 'deli  - quick dry -  No - 7286 ( 12 in each pack) No - 7286\r\n'),
(61, 'Correction fluid', 'Deli - No - 39291'),
(62, 'Chart paper', 'white - Sky\r\n & blue');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store_item`
--

CREATE TABLE IF NOT EXISTS `tbl_store_item` (
  `date` date NOT NULL,
  `item_id` int(3) NOT NULL AUTO_INCREMENT,
  `category_id` int(3) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(3) NOT NULL,
  `item_source` varchar(25) NOT NULL,
  `item_remarks` text NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=66 ;

--
-- Dumping data for table `tbl_store_item`
--

INSERT INTO `tbl_store_item` (`date`, `item_id`, `category_id`, `item_specification`, `item_quantity`, `item_source`, `item_remarks`) VALUES
('2014-08-05', 1, 1, 'Celeron Processor', 1, 'Dhaka', 'Used Laptop'),
('2014-08-05', 6, 1, 'Duel Core', 3, 'Dhaka Office', 'Brand: Fujitsu'),
('2014-08-05', 7, 1, 'Core i3', 24, 'Dhaka Office', 'Brand:Latitude,Vostro,'),
('2014-08-05', 8, 3, 'CP-X2521WN', 16, 'Dhaka Office', 'Class Room'),
('2014-08-05', 9, 3, 'optoma', 3, 'Dhaka Office', 'Class Room'),
('2014-08-05', 10, 3, 'Sony', 5, 'Dhaka Office', 'Class Room'),
('2014-08-05', 11, 5, 'HP Laserjet', 27, 'Dhaka Office', 'Class Room'),
('2014-08-05', 12, 20, 'HP laserjet P2055dn', 3, 'Dhaka Office', ''),
('2014-08-05', 14, 21, 'color printer', 1, 'Dhaka Office', ''),
('2014-08-05', 15, 6, 'Speaker', 26, 'Dhaka Office', 'Brand:Microlab,Creatibe'),
('2014-08-05', 17, 9, 'Netgear Switch 8 port', 14, 'Dhaka Office', 'campus'),
('2014-08-05', 19, 11, 'Netgear Switch 24 Port', 2, 'Dhaka Office', 'Campus'),
('2014-08-05', 20, 14, 'Netgear', 36, 'Dhaka Office', 'Brand:Netgear,TP Link'),
('2014-08-05', 21, 22, 'Netgaer', 8, 'Dhaka Office', 'Brand:Netgare'),
('2014-08-05', 22, 23, 'netgare', 1, 'Dhaka Office', ''),
('2014-08-05', 23, 15, 'Micro power Supply', 4, 'Dhaka Office', ''),
('2014-08-05', 24, 16, 'Micro power supply', 8, 'Dhaka Office', 'Campus'),
('2014-08-05', 25, 19, 'Power tree 100VA', 4, 'Dhaka Office', 'Campus'),
('2014-08-05', 26, 17, 'Power Tree 750VA', 12, 'Dhaka Office', 'campus'),
('2014-08-05', 27, 18, 'CC camera', 40, 'Dhaka Office', 'Campus'),
('2014-08-05', 28, 2, 'Duel Core', 3, 'Dhaka Office', 'Campus'),
('2014-08-05', 29, 2, 'Core i5', 1, 'Dhaka Office', 'campus'),
('2014-08-05', 32, 24, 'A4 Tech', 10, 'Dhaka office', ''),
('2014-08-05', 34, 31, 'HP P1102', 27, 'HP Lajerjet', ''),
('2014-08-05', 35, 6, 'Microlab', 27, 'Dhaka office', ''),
('2014-08-05', 36, 6, 'Microlab', -27, 'Dhaka office', ''),
('2014-08-05', 37, 6, 'microlab', 1, 'Dhaka office', ''),
('2014-08-05', 38, 29, 'Dell Laptop bag', 4, 'Dhaka Office', 'for teacher'),
('2014-08-05', 39, 4, 'Canon 110', 10, 'Dhaka office', ''),
('2014-08-05', 40, 20, 'HP laserjet ', -1, 'Dhaka Office', ''),
('2014-08-05', 41, 31, 'HP p1102', 2, 'Dhaka Office', ''),
('2014-08-05', 42, 36, 'Grandstream IP Phone Dorm-1', 1, 'Dhaka office', ''),
('2014-08-05', 43, 10, 'Netgear switch 16 port', 20, 'Dhaka office', ''),
('2014-08-05', 44, 25, 'Multiplug 5port', 22, 'Dhaka office', ''),
('2014-10-29', 45, 35, 'Internal Hard disk ', 2, 'Dhaka office', ''),
('2014-10-29', 46, 36, 'Fujitsu laptop Charger', 1, 'Dhaka office', ''),
('2014-08-05', 47, 2, 'Desktop core i3', 41, 'Dhaka office', ''),
('2014-08-05', 48, 8, 'Grandsteam ', 43, 'Dhaka office', ''),
('2014-10-29', 49, 37, 'Fujitsu Laptop Charger Movie night', 1, 'Dhaka office', ''),
('2014-08-08', 50, 32, 'External Hard disk', 1, 'Dhaka office', ''),
('2014-08-08', 51, 34, 'Short cable', 1, 'Dhaka office', ''),
('2014-08-08', 52, 30, 'Cosonic Headphone', 1, 'Dhaka office', ''),
('2014-08-08', 53, 29, 'Dell inspiron', 1, 'Dhaka office', ''),
('2014-08-08', 54, 26, 'Nokia ', 3, 'Dhaka office', ''),
('2014-08-08', 55, 28, 'A4 Tech Mouse', 8, 'Dhaka office', ''),
('2014-08-08', 56, 4, 'Scanner Lide 110', -1, 'Dhaka office', ''),
('2014-08-08', 57, 33, 'Smartboard ', 5, 'Dhaka office', ''),
('2014-12-30', 58, 17, 'Power tree 750VA', 5, 'Dhaka office', ''),
('2014-08-08', 59, 17, 'Power Tree ', 5, 'Dhaka office', ''),
('2014-08-08', 60, 27, 'long VGA cable ', 2, 'Dhaka office', ''),
('2014-11-05', 61, 28, 'A4 Tech Mouse ', 1, 'Dhaka office', ''),
('2014-11-29', 62, 2, 'Core i3,Hard disk 500GV,Ram-2GB', 1, 'Computer Lab', ''),
('2014-12-04', 63, 25, '5 port Multiplug', 1, 'Dhaka office', ''),
('2015-02-27', 64, 38, '50 gram pack', 20, 'Agora', ''),
('2015-02-23', 65, 47, 'blue', 4, 'Dhaka corporate', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test_disribute`
--

CREATE TABLE IF NOT EXISTS `tbl_test_disribute` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `receiver_id` int(5) NOT NULL,
  `item_id` int(3) NOT NULL,
  `qty` int(3) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_test_disribute`
--

INSERT INTO `tbl_test_disribute` (`id`, `date`, `receiver_id`, `item_id`, `qty`, `remarks`) VALUES
(1, '2015-03-10', 1, 1, 1, 'test'),
(2, '2015-03-10', 2, 2, 20, 'test2'),
(3, '2015-03-29', 123, 11, 0, ''),
(4, '0000-00-00', 0, 22, 0, ''),
(5, '2015-03-29', 11, 1, 0, ''),
(6, '0000-00-00', 0, 11, 0, ''),
(7, '2015-03-29', 123, 12, 0, ''),
(8, '0000-00-00', 0, 23, 0, ''),
(9, '2015-03-29', 22, 22, 0, ''),
(10, '0000-00-00', 0, 22, 0, ''),
(11, '2015-03-30', 321, 21, 21, 'wwzz'),
(12, '0000-00-00', 0, 22, 22, ''),
(13, '2015-03-26', 0, 99, 2, 'just test'),
(14, '2015-03-26', 0, 100, 3, 'just test');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_test_form_1`
--

CREATE TABLE IF NOT EXISTS `tbl_test_form_1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `part_id` varchar(20) NOT NULL,
  `quantity` int(3) NOT NULL,
  `price` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_test_form_1`
--

INSERT INTO `tbl_test_form_1` (`id`, `part_id`, `quantity`, `price`) VALUES
(1, 'hdd', 3, '2424'),
(2, 'dfd', 423, '3434');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
