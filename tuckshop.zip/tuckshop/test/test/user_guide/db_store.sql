-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2014 at 03:21 AM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_login`
--

CREATE TABLE IF NOT EXISTS `tbl_admin_login` (
  `admin_id` int(3) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(50) NOT NULL,
  `admin_email_address` varchar(100) NOT NULL,
  `admin_password` varchar(32) NOT NULL,
  `role` tinyint(1) NOT NULL COMMENT 'administrator=1, user=2, viewer=3',
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_admin_login`
--

INSERT INTO `tbl_admin_login` (`admin_id`, `admin_name`, `admin_email_address`, `admin_password`, `role`) VALUES
(1, 'Suman Sen', 'suman.sen@pledgeharbor.org', 'phsa8115417', 1),
(2, 'habiba', 'habiba@phsa.com', '123456', 2),
(3, 'sudeb', 'sudeb.das@pledgeharbor.org', '123456', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_defect_item`
--

CREATE TABLE IF NOT EXISTS `tbl_defect_item` (
  `defect_id` int(7) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `item_id` int(2) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(4) NOT NULL,
  `defect_type` text NOT NULL,
  `item_remarks` text NOT NULL,
  PRIMARY KEY (`defect_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_defect_item`
--

INSERT INTO `tbl_defect_item` (`defect_id`, `date`, `item_id`, `item_specification`, `item_quantity`, `defect_type`, `item_remarks`) VALUES
(1, '2026-02-14', 1, 'fdsfs fdsffs', 2, 'not take power', 'grre er ete e'),
(2, '2026-02-14', 2, 'tgtrh', 1, 'broken', 'fbfbr tht '),
(3, '2028-02-14', 8, 'rvgergh tr', 3, 'rgre g htth', 'thtrhtr thyhty'),
(4, '2028-02-14', 3, '2 GB Ram', 2, 'sfdfds r g', 'rgreg gtrht'),
(5, '2014-09-22', 1, '', 0, '', ''),
(6, '0000-00-00', 0, '', 0, '', ''),
(7, '2014-09-22', 1, 'WD 500 GB', 1, 'not worked', ''),
(8, '2014-09-22', 2, 'Dell Vostro 1450', 1, 'don''t turn on ', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_distribute`
--

CREATE TABLE IF NOT EXISTS `tbl_distribute` (
  `distribute_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `receiver_id` varchar(50) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `item_id` varchar(25) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(11) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`distribute_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `tbl_distribute`
--

INSERT INTO `tbl_distribute` (`distribute_id`, `date`, `receiver_id`, `designation`, `item_id`, `item_specification`, `item_quantity`, `remarks`) VALUES
(1, '2012-01-14', '1', 'IT Assistant', '1', 'dfdfd', 1, '0'),
(2, '2022-02-14', '2', 'Nurse', '3', '2 GB Transend', 2, '0'),
(4, '2023-02-14', '4', 'Jr. Administrator', '1', 'gdfhbrb ', 2, '0'),
(5, '2026-02-14', '4', 'Jr. Administrator', '1', 'poefje', 1, '0'),
(6, '2028-02-14', '3', 'IT Manager', '8', 'a4 tech', 1, '0'),
(7, '2028-02-14', '1', 'IT Assistant', '2', 'dfd rger', 2, '0'),
(8, '0000-00-00', '4', 'Jr. Administrator', '8', 'y5reuu', 1, '0'),
(9, '2014-03-13', '1', 'IT Assistant', '1', 'dgsas', 1, '0'),
(10, '2014-09-01', '4', 'Jr. Administrator', '2', 'Dell Vostro 1450 Core i3 ', 1, '0'),
(11, '0000-00-00', 'Select Receiver name', 'Select Designation', 'Select your item name', '', 0, '0'),
(12, '2014-09-14', '6', 'HM', '3', 'Transend 2 GB', 2, '0'),
(13, '2014-09-22', '1', 'Officer, IT Administratio', '1', 'WD 500 GB', 1, '0'),
(14, '2014-09-22', '1', 'Officer, IT Administratio', '1', 'WD 500GB ', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_employee`
--

CREATE TABLE IF NOT EXISTS `tbl_employee` (
  `employee_id` int(3) NOT NULL AUTO_INCREMENT,
  `employee_name` varchar(50) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `employee_status` tinyint(1) NOT NULL COMMENT 'employee_status_Active=1, Employee_Status_inactive=0',
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_employee`
--

INSERT INTO `tbl_employee` (`employee_id`, `employee_name`, `designation`, `employee_status`) VALUES
(1, 'Suman sen', 'Officer, IT Administratio', 1),
(2, 'Sudeb Das', 'Senior Nurse', 0),
(3, 'Rahul Karim', 'IT Manager', 0),
(4, 'Dulon Ukil', 'Jr. Administrator', 0),
(6, 'Arif Hasan', 'HM', 1),
(7, 'Hasib Zaman', 'VP Office Administrator', 1),
(8, 'Rakibul Hasan', 'Lab Assistant and HM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_return`
--

CREATE TABLE IF NOT EXISTS `tbl_return` (
  `return_id` int(7) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `returner_id` varchar(32) NOT NULL,
  `designation` varchar(25) NOT NULL,
  `item_id` int(3) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(4) NOT NULL,
  `remarks` text NOT NULL,
  PRIMARY KEY (`return_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_return`
--

INSERT INTO `tbl_return` (`return_id`, `date`, `returner_id`, `designation`, `item_id`, `item_specification`, `item_quantity`, `remarks`) VALUES
(1, '0000-00-00', 'Select Returner name', 'Select Designation', 0, '', 0, '0'),
(2, '2014-09-23', '1', 'Officer, IT Administratio', 1, 'WD 500 GB', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store_category`
--

CREATE TABLE IF NOT EXISTS `tbl_store_category` (
  `st_category_id` int(3) NOT NULL AUTO_INCREMENT,
  `st_category_name` varchar(25) NOT NULL,
  `st_category_description` text NOT NULL,
  PRIMARY KEY (`st_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_store_category`
--

INSERT INTO `tbl_store_category` (`st_category_id`, `st_category_name`, `st_category_description`) VALUES
(1, 'Hard Disk', 'WD External Hard Disk'),
(2, 'Laptop', 'Dell vostro 1540'),
(3, 'RAM', 'Random access Memory'),
(4, 'DVD ROM', 'DVD ROM'),
(8, 'Mouse', 'Optical Mouse'),
(9, 'Projector', 'Hitachi CP2521wn'),
(10, 'Speaker', 'Speaker 2:1'),
(11, 'Desktop', 'Dell brand Desktop');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_store_item`
--

CREATE TABLE IF NOT EXISTS `tbl_store_item` (
  `date` date NOT NULL,
  `item_id` int(3) NOT NULL AUTO_INCREMENT,
  `category_id` int(3) NOT NULL,
  `item_specification` text NOT NULL,
  `item_quantity` int(3) NOT NULL,
  `item_source` varchar(25) NOT NULL,
  `item_remarks` text NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=58 ;

--
-- Dumping data for table `tbl_store_item`
--

INSERT INTO `tbl_store_item` (`date`, `item_id`, `category_id`, `item_specification`, `item_quantity`, `item_source`, `item_remarks`) VALUES
('2014-08-29', 22, 1, 'Suman', 2, 'dhaka', 'for suman'),
('2012-01-14', 23, 2, 'Dell vostro', 3, 'hsabc', 'susmoy'),
('2010-01-14', 24, 2, 'susmoy', 3, 'susmoy', 'fds dsds'),
('2010-01-14', 25, 2, 'dfsddg', 3, 'susmoy', 'gdsgsd'),
('2010-01-14', 26, 2, 'dfsddg', 3, 'susmoy', 'gdsgsd'),
('2014-08-29', 27, 1, 'wd', 5, 'dhaka', 'f sdojfsdojf'),
('2010-01-14', 28, 1, 'fsfs', 4, 'bangladesh', 'dfdg'),
('2010-01-14', 29, 1, 'fsfs', 4, 'bangladesh', 'dfdg'),
('2014-09-06', 31, 3, '2 GB DDR3', 2, 'datatech', 'TRransend'),
('2014-09-06', 32, 1, '500 GB WD', 10, 'corporate', ''),
('0000-00-00', 33, 1, 'ewgdrgh', 2, 'Sudeb', ' dfjdsfpas[f '),
('2014-03-13', 44, 4, 'lite on', 2, 'corporate office', 'mazhar'),
('2014-03-13', 47, 2, 'vostor', 2, 'corporate office', 'sagagaga'),
('2014-03-14', 48, 1, 'toshiba', 4, 'corporate office', 'bd'),
('2014-03-14', 49, 1, 'wd', 13, 'computer source', 'fsgdbds'),
('2014-08-29', 50, 1, 'Hitachi 500 GB', 2, 'datatech', 'for Doctor'),
('2014-09-06', 51, 2, 'Dell vostro 1450', 10, 'Dhaka', ''),
('2014-09-14', 52, 0, '', 1, '', ''),
('2014-09-14', 53, 1, 'Hitachi 500 GB', 1, 'Dhaka', 'dfsdaf'),
('2014-09-14', 54, 3, 'Transend', 2, 'Datatech', 'dfsdf'),
('2014-09-14', 55, 8, 'A4 Tech', 3, 'corporate', 'dsfsaf'),
('2014-09-14', 56, 10, 'Creative 2:1', 5, 'dhaka', 'dasdsd'),
('2014-09-14', 57, 9, 'Hitachi 2521 wn', 4, 'dfsd', 'fsdf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
