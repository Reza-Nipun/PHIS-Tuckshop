
$jQuery(document).ready(function() {
    //when the Add Field button is clicked
    $("#add").click(function() {
        //Append a new row of code to the "#items" div
        $("#items").append('<div><input type="text" name="item_id[]"><button class="delete">Delete</button></div>');
    });
    
    $("body").on("click", ".delete", function() {
    $(this).parent("div").remove();
    });
    
    
    
});


  
        
       
$(document).ready(function() {

    $("#add_li").click(function() {
        $("ol").append("<li></li>");
    });

    $("#remove_li").click(function() {
        $("li:last").remove();
    });

});
