



<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.3.2.min.js"></script>



<h3 style="text-align: center;">Sales Product </h3>
<hr>
<h4 style="text-align: center;">
    <?php
        $message=$this->session->userdata('message');
        if(isset($message))
        {
            echo $message;
            $this->session->unset_userdata('message');
        }
    
    
    ?>
</h4>



<script type="text/javascript">

    $(document).ready(function() {

        var counter = 2;

        $("#addButton").click(function() {

            if (counter > 10) {
                alert("Only 10 textboxes allow");
                return false;
            }

            var newTextBoxDiv = $(document.createElement('tr'))
                    .attr("id", 'TextBoxDiv' + counter);




            newTextBoxDiv.before().html('<label>Product ID #' + counter + ' : </label>' +
                    '<input type="text" name="product_id[]" size="15" required="required" value="">' + '<label>Quantity : </label>' +
                    '<input type="number" name="quantity[]" required="required">'+
                    '<label>Unit Price : </label>' +'<input type="number" name="unit_price[]" required="required" value="">');

            newTextBoxDiv.appendTo("#add_sales");


            counter++;
        });

        $("#removeButton").click(function() {
            if (counter == 1) {
                alert("No more textbox to remove");
                return false;
            }

            counter--;

            $("#TextBoxDiv" + counter).remove();

        });

        $("#getButtonValue").click(function() {

            var msg = '';
            for (i = 1; i < counter; i++) {
                msg += "\n Textbox #" + i + " : " + $('#textbox' + i).val();
            }
            alert(msg);
        });
    });
</script>


<?php if($this->session->userdata('role') == 1||$this->session->userdata('role') == 3): ?>

<div id="add_sales_form">
    <form action="<?php echo base_url();?>store_category/save_sales_product" method="post" id="add_sales">
    
    <table cellspacing="10px" align="center">
        <tr>
            <td>Date</td>
            <td>
                
                <input type='date' id='date' name='date[]' required="required" value="">
                
            </td>
        </tr>
        <tr>
            <td>Customer ID</td>
            <td>
                <input type="text" name="customer_id[]" size="15" required="required" value="">
            </td>
        </tr>

        <tr>
            <td>Product ID</td>
            <td>
                <input type="text" name="product_id[]" size="15" required="required" value="">
            </td>
        
            <td>Quantity</td>
            <td>
                <input type="number" name="quantity[]" required="required" value="">
            </td>
        
            <td>Unit Price</td>
            <td>
                <input type="number" name="unit_price[]"  required="required" value="">
            </td>
            
        </tr>

        
        <tr>
            <td>&nbsp;</td>
            
            
            <td>
                    <input type='button' value='Add More Product!' id='addButton'>
                </td>
                <td>
                    <input type='button' value='Remove One' id='removeButton'>
                </td>
                <td>
                <input type="submit" name="btn" value="Save">
            </td>
        </tr>
    </table>
</form> 
</div>

<?php endif;?>
